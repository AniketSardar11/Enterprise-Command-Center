# Enterprise Command Center

A multi-client signal-monitoring board for implementation/configuration
cases across hotel brand accounts. The home screen shows one tile per
client; clicking a live client opens its full board — 13 case-type
categories, a team/task view, and one-week SLA tracking with overdue
highlighting.

Right now **Hilton** is the only client wired to a real backend (SFDC).
Radisson, Choice, and Hyatt appear as "Coming soon" tiles on the home
screen — the frontend is already structured to light them up the moment
each one gets its own backend endpoint (see `src/data/clients.js`).

## Structure

```
backend/    Express API — pulls + normalizes Hilton cases from the internal
            SFDC SOQL proxy, groups them into 13 categories.
frontend/   React + Vite dashboard:
              EnterpriseHome  → client tiles (home screen)
              ClientBoard     → per-client board: category grid + team tab
              CaseDrawer      → drill-in case list for one category
              TeamPanel       → cases grouped by owner, overdue-first
```

## Running it

**Backend** (port 4001 by default):
```
cd backend
npm install
cp .env.example .env   # fill in SFDC_PROXY_URL / SFDC_PROXY_KEY if not already set
npm run dev
```

**Frontend** (port 5173, proxies `/api` to the backend in dev):
```
cd frontend
npm install
npm run dev
```

For a production build, set `VITE_API_BASE` to the deployed backend's origin
before running `npm run build` if the frontend won't be served from the same
origin as the backend.

## Design notes

The theme is light and fresh rather than dark — white/near-white surfaces,
a deep teal brand color for chrome and client tiles, and semantic colors
reserved for status: amber = active, blue = pending on client, green =
done, **red = overdue**. Case numbers and property codes stay in IBM Plex
Mono throughout, since that data is inherently alphanumeric (`BPTPR`,
`YNGEE`, `03375782`) and reads better fixed-width than proportional.

**Overdue logic** (`src/utils/sla.js`): any case that's still `active` more
than **7 days** after it was last touched is flagged overdue — red signal
bar, red border on its category card, a red row in the case drawer, and a
red badge on the client tile and team cards. This is currently a single
flat SLA for every case reason; swapping in per-category SLAs later is a
one-line change (`isOverdue(case, slaDays)` already takes an override).

**Team & tasks** (`src/components/TeamPanel.jsx`): groups open cases by
`ownerName` (the SFDC case owner) as a stand-in for task assignment, sorted
overdue-first. This is a proxy, not a real task-management integration —
once there's an actual Projects/task data source, this panel is the place
to wire it in without changing the rest of the board.

## Known gaps / next steps

- Only Hilton has a live backend. Radisson/Choice/Hyatt tiles are
  placeholders until their SFDC integrations exist.
- "Team & tasks" is derived from case ownership, not a real task/member
  system — there's no assignment history, capacity, or due-date data yet.
- The 7-day SLA is uniform across all 13 case types; it may need to vary
  by category once the actual SLA policy is confirmed.
