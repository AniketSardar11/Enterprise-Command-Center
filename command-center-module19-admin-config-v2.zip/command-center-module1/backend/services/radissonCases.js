const { categorizeBySubject, getCategoryMeta, getAllRadissonCategories } = require('../config/radissonTaxonomy');
const { cached } = require('../utils/cache');
const { getField, deriveOperationalStatus, fetchClientCases } = require('./sfdcCaseFetcher');
const { extractDateAfterTrigger } = require('../utils/extractDateFromText');
const { buildClientWhereClause } = require('../config/clientIdentifiers');

// Confirmed from Salesforce Account layout: the Chain Code field API name is
// Chain_Code_Lookup__c is a lookup field. The chain-code text is exposed in
// SOQL through the related record as Account.Chain_Code_Lookup__r.Name.
// IN ('RHAB', 'RHGA') — precise field match, replacing the earlier
// Account.Name LIKE '%Radisson%' guess.
const BASE_WHERE = buildClientWhereClause('radisson');

const DONE_SINCE = '2026-01-01T00:00:00Z';

const FIELDS = `
  Id, CaseNumber, Reason, Type, Subject, Description, Status, IsClosed,
  CreatedDate, LastModifiedDate,
  Owner.Name, CreatedBy.Name,
  Account.Name, Account.AccountNumber, Account.Client_Property_Code__c,
  Account.G3_Client_Code__c, Account.Chain_Code_Lookup__r.Name
`;

function normalizeCase(record) {
  const subject = getField(record, 'Subject');
  const description = getField(record, 'Description');
  const categoryKey = categorizeBySubject(subject);
  const categoryMeta = getCategoryMeta(categoryKey);
  const status = getField(record, 'Status');

  // Rebuild cases carry their scheduled date as "DATE: Monday Oct 5 2026"
  // in the description, confirmed from real examples — same grammar as
  // Hilton's rebuild dates, different trigger phrase.
  const scheduledDate = categoryKey === 'rebuild' ? extractDateAfterTrigger(description, /DATE:\s*/i) : null;

  return {
    id: getField(record, 'CaseNumber'),
    source: 'sfdc',
    client: 'Radisson',
    clientCode: getField(record, 'Account.G3_Client_Code__c') || null,
    chainCode: getField(record, 'Account.Chain_Code_Lookup__r.Name') || null,
    propertyCode: getField(record, 'Account.Client_Property_Code__c') || null,

    categoryKey,
    categoryLabel: categoryMeta.label,

    reason: getField(record, 'Reason') || null,
    type: getField(record, 'Type') || null,
    subject: subject || null,
    description: description || null,
    scheduledDate,

    sfdcStatus: status || null,
    operationalStatus: deriveOperationalStatus(status),

    accountName: getField(record, 'Account.Name') || null,
    ownerName: getField(record, 'Owner.Name') || null,
    createdByName: getField(record, 'CreatedBy.Name') || null,

    createdDate: getField(record, 'CreatedDate') || null,
    lastModifiedDate: getField(record, 'LastModifiedDate') || null,
    isClosed: !!getField(record, 'IsClosed'),

    caseUrl: getField(record, 'Id')
      ? `https://ideas-sas.lightning.force.com/lightning/r/Case/${getField(record, 'Id')}/view`
      : null,
  };
}

async function getRadissonCasesUncached() {
  const { records, operationalRecordCount, doneRecordCount, doneTruncated, operationalSoqlUsed } =
    await fetchClientCases({ fields: FIELDS, baseWhere: BASE_WHERE, doneSince: DONE_SINCE });

  const normalized = records.map(normalizeCase);

  const grouped = getAllRadissonCategories().reduce((acc, cat) => {
    acc[cat.key] = {
      label: cat.label,
      description: cat.description,
      cases: [],
      counts: { active: 0, pending_client: 0, done: 0, unknown: 0 },
    };
    return acc;
  }, {
    uncategorized: {
      label: 'Other / Uncategorized',
      description: getCategoryMeta('uncategorized').description,
      cases: [],
      counts: { active: 0, pending_client: 0, done: 0, unknown: 0 },
    },
  });

  normalized.forEach((c) => {
    const bucket = grouped[c.categoryKey] || grouped.uncategorized;
    bucket.cases.push(c);
    bucket.counts[c.operationalStatus] = (bucket.counts[c.operationalStatus] || 0) + 1;
  });

  return {
    total: normalized.length,
    fetchedAt: new Date().toISOString(),
    cases: normalized,
    byCategory: grouped,
    doneTruncated,
    debug: {
      operationalRecordCount,
      doneRecordCount,
      doneFetchHitPageCap: doneTruncated,
      sampleRawRecord: records[0] || null,
      operationalSoqlUsed,
    },
  };
}

const CACHE_TTL_MS = 3 * 60 * 1000;

async function getRadissonCases() {
  return cached('radisson-cases', CACHE_TTL_MS, getRadissonCasesUncached);
}

/** Rebuild cases with a parsed scheduled date, for a future Calendar tab — mirrors Hilton's rebuild-schedule shape. */
async function getRadissonRebuildSchedule() {
  const { cases, fetchedAt } = await getRadissonCases();
  const rebuildCases = cases.filter((c) => c.categoryKey === 'rebuild' && c.operationalStatus !== 'done');

  const items = rebuildCases.map((c) => ({
    id: c.id,
    propertyCode: c.propertyCode,
    accountName: c.accountName,
    scheduledDate: c.scheduledDate,
    operationalStatus: c.operationalStatus,
    caseUrl: c.caseUrl,
    source: 'sfdc',
    client: 'Radisson',
  }));

  return {
    total: items.length,
    fetchedAt,
    items,
    debug: { unparsedDateCount: items.filter((i) => !i.scheduledDate).length },
  };
}

module.exports = { getRadissonCases, getRadissonRebuildSchedule, normalizeCase };
