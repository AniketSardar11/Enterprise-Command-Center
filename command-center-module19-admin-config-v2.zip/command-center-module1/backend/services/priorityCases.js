const { cached } = require('../utils/cache');
const { T_PRIORITY_TIERS, VALID_T_PRIORITIES, isTPriority, getTierMeta } = require('../config/priorityTaxonomy');
const { getField, deriveOperationalStatus, fetchClientCases } = require('./sfdcCaseFetcher');
const { matchesClient } = require('../config/clientIdentifiers');

// Confirmed via the "New Cases with Activates Report": T-cases are defined
// by Priority, not Reason or Type — cases can be almost any Reason/Type as
// long as Priority is one of these values.
const PRIORITY_LIST = VALID_T_PRIORITIES.map((p) => `'${p}'`).join(', ');

// Same completeness-vs-speed split as other clients: done cases only from
// this year, operational (open) cases unrestricted.
const DONE_SINCE = '2026-01-01T00:00:00Z';

const FIELDS = `
  Id, CaseNumber, Reason, Type, Subject, Description, Status, IsClosed, Priority,
  CreatedDate, LastModifiedDate,
  Owner.Name, CreatedBy.Name,
  Account.Name, Account.AccountNumber, Account.Client_Property_Code__c,
  Account.G3_Client_Code__c, Account.Chain_Code_Lookup__r.Name
`;

// NOTE: this deliberately does NOT yet replicate every filter from the
// source report (Access Flag = External, Product Environment != Casper,
// owner-queue exclusions) — those use custom fields whose exact API names
// aren't confirmed yet. Once confirmed, add them here the same way Reason
// matching was tightened for IM cases.
const BASE_WHERE = `Priority IN (${PRIORITY_LIST})`;

function normalizeCase(record) {
  const status = getField(record, 'Status');
  return {
    id: getField(record, 'CaseNumber'),
    source: 'sfdc',
    clientCode: getField(record, 'Account.G3_Client_Code__c') || null,
    chainCode: getField(record, 'Account.Chain_Code_Lookup__r.Name') || null,
    accountName: getField(record, 'Account.Name') || null,
    propertyCode: getField(record, 'Account.Client_Property_Code__c') || null,

    priority: getField(record, 'Priority') || null,
    reason: getField(record, 'Reason') || null,
    type: getField(record, 'Type') || null,
    subject: getField(record, 'Subject') || null,
    description: getField(record, 'Description') || null,

    sfdcStatus: status || null,
    operationalStatus: deriveOperationalStatus(status),

    ownerName: getField(record, 'Owner.Name') || null,
    createdByName: getField(record, 'CreatedBy.Name') || null,

    createdDate: getField(record, 'CreatedDate') || null,
    lastModifiedDate: getField(record, 'LastModifiedDate') || null,
    isClosed: !!getField(record, 'IsClosed'),

    caseUrl: getField(record, 'Id')
      ? `https://ideas-sas.lightning.force.com/lightning/r/Case/${getField(record, 'Id')}/view`
      : null,
  };
}

async function getAllPriorityCasesUncached() {
  const { records, operationalRecordCount, doneRecordCount, doneTruncated, operationalSoqlUsed } =
    await fetchClientCases({ fields: FIELDS, baseWhere: BASE_WHERE, doneSince: DONE_SINCE });

  const normalized = records.map(normalizeCase).filter((c) => isTPriority(c.priority));

  return {
    cases: normalized,
    doneTruncated,
    debug: {
      operationalRecordCount,
      doneRecordCount,
      doneFetchHitPageCap: doneTruncated,
      sampleRawRecord: records[0] || null,
      operationalSoqlUsed,
    },
  };
}

const CACHE_TTL_MS = 3 * 60 * 1000;

async function getAllPriorityCases() {
  return cached('priority-cases-all', CACHE_TTL_MS, getAllPriorityCasesUncached);
}

/**
 * Get T-priority cases for one client, grouped by priority tier.
 * @param {string} clientKey e.g. 'hilton', 'radisson' (matches config/clients.js keys)
 */
async function getPriorityCasesForClient(clientKey) {
  const { cases: allCases, doneTruncated, debug } = await getAllPriorityCases();
  const clientCases = allCases.filter((c) => matchesClient(c, clientKey));

  const grouped = T_PRIORITY_TIERS.reduce((acc, tier) => {
    acc[tier.key] = {
      label: tier.label,
      description: tier.description,
      cases: [],
      counts: { active: 0, pending_client: 0, done: 0, unknown: 0 },
    };
    return acc;
  }, {});

  clientCases.forEach((c) => {
    const bucket = grouped[c.priority] || (grouped[c.priority] = {
      label: c.priority || 'Unknown',
      description: getTierMeta(c.priority).description,
      cases: [],
      counts: { active: 0, pending_client: 0, done: 0, unknown: 0 },
    });
    bucket.cases.push(c);
    bucket.counts[c.operationalStatus] = (bucket.counts[c.operationalStatus] || 0) + 1;
  });

  return {
    total: clientCases.length,
    fetchedAt: new Date().toISOString(),
    cases: clientCases,
    byPriority: grouped,
    doneTruncated,
    debug: {
      ...debug,
      clientKey,
      totalAcrossAllClients: allCases.length,
    },
  };
}

module.exports = { getAllPriorityCases, getPriorityCasesForClient, normalizeCase };
