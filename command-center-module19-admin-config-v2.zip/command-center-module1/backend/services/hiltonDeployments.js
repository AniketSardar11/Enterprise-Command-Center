const { getSheet, flattenSheet, parseSmartsheetDate } = require('./smartsheet');

// From the "All of the Things Rollup" sheet, "Planned Deployments_Grouped by
// Deployment Team" table (HLTN_RDA_Rollout_Tracker sheet).
// Confirm this ID matches whichever sheet actually holds the table once tested.
const HILTON_DEPLOYMENT_SHEET_ID = process.env.HILTON_DEPLOYMENT_SHEET_ID || '8104543993679748';

function parsePropertyCount(raw) {
  if (raw === null || raw === undefined || raw === '') return 0;
  const n = parseInt(String(raw).replace(/[^\d-]/g, ''), 10);
  return Number.isNaN(n) ? 0 : n;
}

/**
 * A row counts as a real deployment/wave (not a group header row like
 * "Task Type: Deployment" or "Assigned To: Blank") if it has both a start
 * and end date. This is more robust than trying to parse Smartsheet's
 * hierarchy/grouping semantics directly, since it works the same whether
 * this sheet uses row hierarchy or is a grouped report view.
 */
function isDataRow(row) {
  return Boolean(parseSmartsheetDate(row['Start Date']) && parseSmartsheetDate(row['End Date']));
}

function normalizeRow(row) {
  return {
    id: String(row.rowId),
    title: row['Primary'] || 'Untitled deployment',
    region: row['Region'] || null,
    propertyCount: parsePropertyCount(row['Impacted Property Count']),
    propertyListUrl: row['Deployment Property List'] || null,
    status: row['Status'] || null,
    startDate: parseSmartsheetDate(row['Start Date']),
    endDate: parseSmartsheetDate(row['End Date']),
    syncRequired: row['Sync Required?'] || null,
    source: 'smartsheet',
    client: 'Hilton',
  };
}

/**
 * Fetch + normalize Hilton's planned deployment waves for the calendar view.
 * `debug` mirrors the Module 1 pattern so we can diagnose from the browser
 * alone if something doesn't parse as expected.
 */
async function getHiltonDeployments() {
  const sheet = await getSheet(HILTON_DEPLOYMENT_SHEET_ID);
  const { columns, rows } = flattenSheet(sheet);

  const dataRows = rows.filter(isDataRow);
  const skippedRows = rows.length - dataRows.length;

  const deployments = dataRows.map(normalizeRow);

  return {
    total: deployments.length,
    fetchedAt: new Date().toISOString(),
    deployments,
    debug: {
      sheetName: sheet.name,
      totalRows: rows.length,
      skippedNonDataRows: skippedRows,
      columnsFound: columns,
      sampleRawRow: rows[0] || null,
    },
  };
}

module.exports = { getHiltonDeployments, parseSmartsheetDate };
