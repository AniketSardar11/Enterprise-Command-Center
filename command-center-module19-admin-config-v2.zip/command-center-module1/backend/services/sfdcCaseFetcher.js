const { runSoql } = require('./sfdc');

/**
 * The proxy returns FLAT dotted-string keys for relationship fields
 * (e.g. record["Account.Name"]) rather than nested objects
 * (record.Account.Name). This helper reads a value whichever way it
 * comes back, so we're resilient if that ever changes.
 */
function getField(record, dottedPath) {
  if (record[dottedPath] !== undefined) return record[dottedPath]; // flat key style
  return dottedPath.split('.').reduce((obj, key) => (obj ? obj[key] : undefined), record);
}

function extractRecords(result) {
  return result.records || result.data || result.results || (Array.isArray(result) ? result : []);
}

/**
 * Derived status — same lifecycle across every client we've seen so far:
 *  - In Progress / New      -> active      (needs eyes)
 *  - Waiting For Response   -> pending_client (we've done our part)
 *  - Closed                 -> done
 */
function deriveOperationalStatus(sfdcStatus) {
  switch ((sfdcStatus || '').trim()) {
    case 'In Progress':
      return 'active';
    case 'Waiting For Response':
      return 'pending_client';
    case 'Closed':
      return 'done';
    case 'New':
      return 'active';
    default:
      return 'unknown';
  }
}

function toDatetimeLiteral(raw) {
  if (!raw) return null;
  return raw.includes('T') ? raw : `${raw}T00:00:00Z`;
}

/**
 * Fetch ALL closed cases matching `baseWhere` since `doneSince`, paginating
 * past the SFDC proxy's 2000-row-per-call cap. Salesforce SOQL's OFFSET
 * itself maxes out at 2000 (can't page past that with OFFSET), so this uses
 * keyset pagination instead: each page asks for rows strictly before the
 * last page's (LastModifiedDate, Id) — a stable, gap-free cursor that works
 * regardless of how many rows share the same LastModifiedDate. Capped at
 * MAX_PAGES as a runaway-loop safety net.
 */
async function fetchAllDoneRecords({ fields, baseWhere, doneSince }) {
  const PAGE_SIZE = 2000;
  const MAX_PAGES = 10; // up to 20,000 done cases — comfortably past realistic per-client volume
  let all = [];
  let cursorDate = null;
  let cursorId = null;
  let hitPageCap = false;

  for (let page = 0; page < MAX_PAGES; page++) {
    const cursorClause = cursorDate
      ? `AND (LastModifiedDate < ${cursorDate} OR (LastModifiedDate = ${cursorDate} AND Id < '${cursorId}'))`
      : '';

    const soql = `
      SELECT ${fields}
      FROM Case
      WHERE ${baseWhere}
        AND Status = 'Closed'
        AND LastModifiedDate >= ${doneSince}
        ${cursorClause}
      ORDER BY LastModifiedDate DESC, Id DESC
      LIMIT ${PAGE_SIZE}
    `;

    // eslint-disable-next-line no-await-in-loop
    const result = await runSoql(soql);
    const records = extractRecords(result);
    all = all.concat(records);

    if (records.length < PAGE_SIZE) break; // last page
    if (page === MAX_PAGES - 1) {
      hitPageCap = true;
      break;
    }

    const last = records[records.length - 1];
    cursorDate = toDatetimeLiteral(getField(last, 'LastModifiedDate'));
    cursorId = getField(last, 'Id');
  }

  return { records: all, hitPageCap };
}

/**
 * Fetch every case matching `baseWhere` for one client: operational
 * (non-closed, unrestricted volume — always complete) plus done/closed
 * cases since `doneSince` (paginated, capped). Splitting these into two
 * queries means closed-case volume can never crowd out the active/pending
 * cases that actually need action — only "done" completeness is ever at risk.
 */
async function fetchClientCases({ fields, baseWhere, doneSince }) {
  const operationalSoql = `
    SELECT ${fields}
    FROM Case
    WHERE ${baseWhere}
      AND Status != 'Closed'
    ORDER BY CreatedDate DESC
    LIMIT 2000
  `;

  // Keep these requests sequential. The proxy rate-limits bursts, and each
  // feed can already fan out into multiple pages for closed cases.
  const operationalResult = await runSoql(operationalSoql);
  const doneFetch = await fetchAllDoneRecords({ fields, baseWhere, doneSince });

  const operationalRecords = extractRecords(operationalResult);
  const { records: doneRecords, hitPageCap } = doneFetch;

  return {
    records: [...operationalRecords, ...doneRecords],
    operationalRecordCount: operationalRecords.length,
    doneRecordCount: doneRecords.length,
    doneTruncated: hitPageCap,
    operationalSoqlUsed: operationalSoql,
  };
}

module.exports = { getField, extractRecords, deriveOperationalStatus, fetchClientCases };
