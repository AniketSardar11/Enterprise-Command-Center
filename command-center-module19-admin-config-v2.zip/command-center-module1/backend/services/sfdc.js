/**
 * SFDC Service
 * -------------------------------------------------------------------------
 * Thin wrapper around the existing internal SOQL proxy at
 * http://172.27.210.162:4000/query (confirmed working via curl).
 *
 * Env vars required (set in .env — see .env.example):
 *   SFDC_PROXY_URL   e.g. http://172.27.210.162:4000/query
 *   SFDC_PROXY_KEY   e.g. key_e3b16a2763a4bd43d3172f38b3e04fe3
 */

const SFDC_PROXY_URL = process.env.SFDC_PROXY_URL;
const SFDC_PROXY_KEY = process.env.SFDC_PROXY_KEY;

if (!SFDC_PROXY_URL || !SFDC_PROXY_KEY) {
  console.warn(
    '[sfdc.js] SFDC_PROXY_URL / SFDC_PROXY_KEY not set — SFDC calls will fail until configured in .env'
  );
}

/**
 * Run a raw SOQL query against the proxy.
 * @param {string} soql
 * @returns {Promise<object>} raw proxy response (expects { records: [...] } shape,
 *   adjust `records` field name below if the proxy wraps results differently)
 */
const MAX_RATE_LIMIT_RETRIES = 3;

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function runSoql(soql) {
  for (let attempt = 0; attempt <= MAX_RATE_LIMIT_RETRIES; attempt++) {
    const res = await fetch(SFDC_PROXY_URL, {
      method: 'POST',
      headers: {
        'x-api-key': SFDC_PROXY_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ soql }),
    });

    if (res.status === 429 && attempt < MAX_RATE_LIMIT_RETRIES) {
      const retryAfter = Number(res.headers.get('retry-after'));
      const delayMs = Number.isFinite(retryAfter) && retryAfter > 0
        ? Math.min(retryAfter * 1000, 15000)
        : Math.min(1000 * (2 ** attempt), 15000);
      await res.text().catch(() => '');
      await sleep(delayMs);
      continue;
    }

    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`SFDC proxy error ${res.status}: ${text}`);
    }

    const json = await res.json();

    // Some internal proxies return 200 OK with an error embedded in the body
    // instead of using HTTP error status codes. Catch that case explicitly so
    // it doesn't silently look like "0 matching records" downstream.
    if (json && json.error) {
      throw new Error(`SFDC proxy returned an error in the response body: ${JSON.stringify(json.error)}`);
    }

    return json;
  }

  throw new Error('SFDC proxy rate limit persisted after retries');
}

module.exports = { runSoql };
