const { getHiltonCases } = require('./hiltonCases');
const { extractDateAfterTrigger } = require('../utils/extractDateFromText');

/**
 * Pulls a scheduled rebuild date out of free-text case descriptions like:
 *   "Please begin the rebuild on 17-August-2026."
 *   "...begin the rebuild on August 25th, 2026."
 * Returns an ISO date string (YYYY-MM-DD) or null if nothing matched.
 */
function parseRebuildDate(description) {
  return extractDateAfterTrigger(description, /rebuild on\s+/i);
}

/**
 * Pulls the Hilton "Rebuild" schedule for the calendar view: cases in the
 * ldb_standard_switch category (Reason = "...Property Rebuild to Standard")
 * that aren't done yet, with their scheduled date parsed out of the
 * description. Cases where the date couldn't be parsed are still returned
 * (with scheduledDate: null) so nothing silently disappears — the frontend
 * can surface those separately as "needs a date" instead of dropping them.
 */
async function getHiltonRebuildSchedule() {
  const { cases, fetchedAt } = await getHiltonCases();

  const rebuildCases = cases.filter(
    (c) => c.categoryKey === 'ldb_standard_switch' && c.operationalStatus !== 'done'
  );

  const items = rebuildCases.map((c) => ({
    id: c.id,
    propertyCode: c.propertyCode,
    accountName: c.accountName,
    scheduledDate: parseRebuildDate(c.description),
    operationalStatus: c.operationalStatus,
    caseUrl: c.caseUrl,
    source: 'sfdc',
    client: 'Hilton',
  }));

  const unparsed = items.filter((i) => !i.scheduledDate).length;

  return {
    total: items.length,
    fetchedAt,
    items,
    debug: {
      totalRebuildCases: rebuildCases.length,
      unparsedDateCount: unparsed,
    },
  };
}

module.exports = { getHiltonRebuildSchedule, parseRebuildDate };
