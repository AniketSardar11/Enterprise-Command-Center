const { categorizeByReason, getCategoryMeta, getAllHiltonCategories } = require('../config/caseTaxonomy');
const { cached } = require('../utils/cache');
const { getField, deriveOperationalStatus, fetchClientCases } = require('./sfdcCaseFetcher');

// Confirmed via live query: Account.G3_Client_Code__c = 'HILTON' (not 'HLTN' as first guessed)
const HILTON_CLIENT_CODE = 'HILTON';

// Fallback: pull a 5-char property code out of free text when
// Client_Property_Code__c is blank (common on "Hilton 02 G3" placeholder accounts).
// Matches patterns like "property BPTPR", "<<HAKLH>>", "for XEBHI"
const PROPERTY_CODE_REGEX = /(?:property|for)\s+([A-Z0-9]{4,6})\b|<<\s*([A-Z0-9]{4,6})\s*>>/;

function extractPropertyCodeFallback(description = '') {
  const match = description.match(PROPERTY_CODE_REGEX);
  if (!match) return null;
  return match[1] || match[2] || null;
}

function normalizeCase(record) {
  const rawPropertyCode = getField(record, 'Account.Client_Property_Code__c');
  const description = getField(record, 'Description');
  const propertyCode = rawPropertyCode || extractPropertyCodeFallback(description);

  const reason = getField(record, 'Reason');
  const categoryKey = categorizeByReason(reason);
  const categoryMeta = getCategoryMeta(categoryKey);

  const status = getField(record, 'Status');

  return {
    id: getField(record, 'CaseNumber'),
    source: 'sfdc',
    client: 'Hilton',
    clientCode: HILTON_CLIENT_CODE,
    propertyCode: propertyCode || null,
    propertyCodeInferred: !rawPropertyCode && !!propertyCode, // flag if we had to guess

    categoryKey,
    categoryLabel: categoryMeta.label,

    reason: reason || null,
    type: getField(record, 'Type') || null,
    subject: getField(record, 'Subject') || null,
    description: description || null,

    sfdcStatus: status || null,
    operationalStatus: deriveOperationalStatus(status),

    accountName: getField(record, 'Account.Name') || null,
    ownerName: getField(record, 'Owner.Name') || null,
    createdByName: getField(record, 'CreatedBy.Name') || null,

    createdDate: getField(record, 'CreatedDate') || null,
    lastModifiedDate: getField(record, 'LastModifiedDate') || null,
    isClosed: !!getField(record, 'IsClosed'),

    caseUrl: getField(record, 'Id')
      ? `https://ideas-sas.lightning.force.com/lightning/r/Case/${getField(record, 'Id')}/view`
      : null,
  };
}

// Scope to what this tool actually tracks: open, implementation-type cases,
// PLUS closed cases from this year (2026-01-01 onward) so "Done" reflects
// real recent throughput instead of always reading 0.
// NOTE: no confirmed `ClosedDate` field on this org's Case object, so
// LastModifiedDate is used as a proxy for "closed since" — swap this for
// ClosedDate if/when we confirm it exists and is populated.
const DONE_SINCE = '2026-01-01T00:00:00Z';

const BASE_WHERE = `
    Account.G3_Client_Code__c = '${HILTON_CLIENT_CODE}'
    AND Type = 'Implementation'
`;

const FIELDS = `
  Id, CaseNumber, Reason, Type, Subject, Description, Status, IsClosed,
  CreatedDate, LastModifiedDate,
  Owner.Name, CreatedBy.Name,
  Account.Name, Account.AccountNumber, Account.Client_Property_Code__c,
  Account.G3_Client_Code__c
`;

/**
 * Fetch + normalize all Hilton cases, grouped by category. The whole result
 * is cached for CACHE_TTL_MS so repeat requests (home tile + board + team
 * panel, all wanting the same data) don't each trigger a fresh multi-page
 * SFDC pull.
 */
async function getHiltonCasesUncached() {
  const { records, operationalRecordCount, doneRecordCount, doneTruncated, operationalSoqlUsed } =
    await fetchClientCases({ fields: FIELDS, baseWhere: BASE_WHERE, doneSince: DONE_SINCE });

  const normalized = records.map(normalizeCase);

  const grouped = getAllHiltonCategories().reduce((acc, cat) => {
    acc[cat.key] = {
      label: cat.label,
      description: cat.description,
      cases: [],
      counts: { active: 0, pending_client: 0, done: 0, unknown: 0 },
    };
    return acc;
  }, { uncategorized: { label: 'Uncategorized', description: 'Reason not mapped — check caseTaxonomy.js', cases: [], counts: { active: 0, pending_client: 0, done: 0, unknown: 0 } } });

  normalized.forEach((c) => {
    const bucket = grouped[c.categoryKey] || grouped.uncategorized;
    bucket.cases.push(c);
    bucket.counts[c.operationalStatus] = (bucket.counts[c.operationalStatus] || 0) + 1;
  });

  return {
    total: normalized.length,
    fetchedAt: new Date().toISOString(),
    cases: normalized,
    byCategory: grouped,
    doneTruncated,
    debug: {
      operationalRecordCount,
      doneRecordCount,
      doneFetchHitPageCap: doneTruncated,
      sampleRawRecord: records[0] || null,
      operationalSoqlUsed,
    },
  };
}

const CACHE_TTL_MS = 3 * 60 * 1000; // 3 minutes — balances freshness against the cost of a multi-page SFDC pull

async function getHiltonCases() {
  return cached('hilton-cases', CACHE_TTL_MS, getHiltonCasesUncached);
}

module.exports = { getHiltonCases, normalizeCase, deriveOperationalStatus, getField };
