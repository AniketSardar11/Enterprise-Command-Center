/**
 * Smartsheet API client.
 * -------------------------------------------------------------------------
 * Docs: https://smartsheet.redoc.ly/ — GET /sheets/{sheetId} returns the
 * sheet's columns (with id + title) and rows (each row's cells reference
 * columnId, not column title), plus a `parentId`/hierarchy on each row that
 * we use to detect group headers (e.g. "Task Type: Deployment") vs actual
 * data rows.
 *
 * Env vars required (see .env.example):
 *   SMARTSHEET_TOKEN   personal access token from
 *                      Account -> Apps & Integrations -> API Access
 */

const SMARTSHEET_TOKEN = process.env.SMARTSHEET_TOKEN;
const BASE_URL = 'https://api.smartsheet.com/2.0';

if (!SMARTSHEET_TOKEN) {
  console.warn('[smartsheet.js] SMARTSHEET_TOKEN not set — Smartsheet calls will fail until configured in .env');
}

async function smartsheetRequest(path) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { Authorization: `Bearer ${SMARTSHEET_TOKEN}` },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Smartsheet API error ${res.status}: ${text}`);
  }

  return res.json();
}

/**
 * Fetch a sheet's full column + row data.
 * Returns raw Smartsheet shape: { columns: [{id, title, ...}], rows: [{id, cells, parentId, ...}] }
 */
function getSheet(sheetId) {
  // rowNumbers/columnType included so we can render hierarchy + detect date/text columns reliably
  return smartsheetRequest(`/sheets/${sheetId}?include=objectValue`);
}

/**
 * Extract a plain display string from one Smartsheet cell, tolerating the
 * handful of shapes the API actually returns depending on column type:
 *  - Most columns (TEXT_NUMBER, single-select PICKLIST, DATE): plain
 *    `value`/`displayValue` string — the common case.
 *  - MULTI_PICKLIST / MULTI_CONTACT columns: no top-level `value` at all —
 *    the selection lives in `objectValue.values` (an array). This matters
 *    here specifically because a "Deployment Status" column type change
 *    (e.g. someone switching it to allow multiple selections) would
 *    otherwise silently make every row look blank/not-done even though
 *    the sheet visibly shows "Complete".
 */
function extractCellText(cell) {
  if (cell.displayValue !== undefined && cell.displayValue !== null) return cell.displayValue;
  if (cell.value !== undefined && cell.value !== null) return cell.value;

  const ov = cell.objectValue;
  if (ov) {
    if (Array.isArray(ov.values)) {
      return ov.values.map((v) => (typeof v === 'string' ? v : v?.name || v?.email || '')).join(', ');
    }
    if (typeof ov.displayValue === 'string') return ov.displayValue;
    if (typeof ov === 'string') return ov;
  }

  return null;
}

/**
 * Build a simplified row shape: { rowId, parentId, <columnTitle>: value, ... }
 * from Smartsheet's columnId-keyed cells. Makes downstream code read by
 * column NAME instead of having to look up columnId -> title every time.
 *
 * Also carries through `sheet.permalink` — the real, working "open in
 * Smartsheet" URL. Smartsheet's actual sheet URLs use an opaque token
 * (e.g. .../sheets/PRMR96wxxmFJX7w6fjjG6Cj3g26P5QcmPVFXg5x1), NOT the
 * numeric sheet ID this app otherwise uses everywhere else — a URL built
 * from the numeric ID looks plausible but 403s ("Access Denied") because
 * it isn't a real Smartsheet identifier at all. `permalink` is a standard
 * field the API returns on every GET /sheets/{id} call, so there's no
 * need to construct a URL by hand; always use this instead.
 */
function flattenSheet(sheet) {
  const colMap = {}; // columnId -> title
  sheet.columns.forEach((c) => {
    colMap[c.id] = c.title;
  });

  const rows = sheet.rows.map((row) => {
    const flat = { rowId: row.id, parentId: row.parentId || null };
    row.cells.forEach((cell) => {
      const title = colMap[cell.columnId];
      if (!title) return;
      flat[title] = extractCellText(cell);
    });
    return flat;
  });

  return { columns: sheet.columns.map((c) => c.title), rows, permalink: sheet.permalink || null };
}

module.exports = { getSheet, flattenSheet, parseSmartsheetDate };

/**
 * Smartsheet date cells commonly display as MM/DD/YY, MM/DD/YYYY, or come
 * back already as ISO (YYYY-MM-DD) depending on the sheet/column setup.
 * Normalizes any of these to a plain ISO date string.
 */
function parseSmartsheetDate(raw) {
  if (!raw) return null;
  const trimmed = String(raw).trim();

  if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) return trimmed.slice(0, 10);

  const match = trimmed.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}|\d{4})$/);
  if (!match) return null;
  let [, mm, dd, yy] = match;
  if (yy.length === 2) yy = `20${yy}`;
  return `${yy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
}
