/**
 * Generic Client Projects
 * -------------------------------------------------------------------------
 * Same idea as genericCases.js but for the Projects tab: reuses Hilton's
 * getProjectStatus() (it already takes generic `{ name, sheetId }` and has
 * no Hilton-specific logic inside — see services/hiltonProjects.js) against
 * whatever Smartsheet sheets have been added for this client through the
 * admin form. No admin-added sheets yet -> an empty project list, not an
 * error.
 */

const { getProjectStatus } = require('./hiltonProjects');
const { getSmartsheetSheetsAsRegistryEntries } = require('./adminConfigStore');
const { cached } = require('../utils/cache');

async function getGenericProjectsSummaryUncached(clientKey) {
  const sheets = getSmartsheetSheetsAsRegistryEntries(clientKey);
  const projects = await Promise.all(sheets.map(getProjectStatus));
  const failedProjects = projects.filter((p) => p.error);

  const aggregate = projects.reduce(
    (acc, p) => {
      acc[p.status] = (acc[p.status] || 0) + 1;
      return acc;
    },
    { ongoing: 0, scheduled: 0, completed: 0 }
  );

  return {
    totalProjects: projects.length,
    projects,
    aggregate,
    fetchedAt: new Date().toISOString(),
    debug: {
      failedProjectCount: failedProjects.length,
      failedProjects: failedProjects.map((p) => ({ name: p.name, sheetId: p.sheetId, error: p.error })),
    },
  };
}

const CACHE_TTL_MS = 10 * 60 * 1000;

async function getGenericProjectsSummary(clientKey) {
  return cached(`${clientKey}-projects`, CACHE_TTL_MS, () => getGenericProjectsSummaryUncached(clientKey));
}

module.exports = { getGenericProjectsSummary };
