const { getSheet, flattenSheet, parseSmartsheetDate } = require('./smartsheet');
const { getHiltonRolloutSchedule, HILTON_ROLLOUT_TRACKER_SHEET_ID } = require('./hiltonRolloutSchedule');
const { getAllHiltonProjectSheets } = require('../config/projectRegistry');
const { cached } = require('../utils/cache');
const { isRowDone } = require('../utils/deploymentStatus');

const SHEET_CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes — matches the projects summary TTL

// Shared per-sheet cache so getProjectStatus() (status rollup) and
// getHiltonProjectSchedule() (calendar events) don't each independently
// re-fetch all 17 sheets — they read the same cached raw sheet data.
function getCachedSheet(sheetId) {
  return cached(`hilton-project-sheet-${sheetId}`, SHEET_CACHE_TTL_MS, () => getSheet(sheetId));
}

// Diagnostic only — a per-project count of raw Deployment Status values, so
// a misclassified project can be root-caused straight from the API response
// (e.g. "why is this showing Ongoing?" -> check statusCounts) instead of
// needing to go pull the sheet by hand.
function tallyStatusCounts(statuses) {
  const counts = {};
  statuses.forEach((s) => {
    const key = s || '(blank)';
    counts[key] = (counts[key] || 0) + 1;
  });
  return counts;
}

/**
 * Project-level status classification
 * -------------------------------------------------------------------------
 * There is no "overdue" concept at the project level — a property-row
 * being past its target date doesn't make the *project* late, it's just
 * part of the project's normal ongoing work. A project is one of exactly
 * three states:
 *
 *   'completed' — every row is done (matches DONE_PATTERN).
 *   'scheduled' — nothing has started yet: zero done rows, and every
 *                 not-done row's System Access date is still in the
 *                 future (or today's not reached). Shown with a
 *                 "starts <date>" using the earliest such date.
 *   'ongoing'   — anything in between: some rows already done, or at
 *                 least one row's timeline has reached/passed today.
 *                 This is the "timeline is current" case — the Smartsheet
 *                 equivalent status here is "In Progress".
 *
 * A project with zero rows can't be scheduled (no date to schedule from)
 * or meaningfully "completed" (nothing to complete), so it falls back to
 * 'ongoing' rather than crashing or reporting something misleading.
 */
function classifyProject(entries) {
  // entries: [{ done: boolean, accessDate: 'YYYY-MM-DD' | null }, ...]
  const total = entries.length;

  if (total === 0) {
    return { status: 'ongoing', startsFrom: null, done: 0, active: 0 };
  }

  const today = new Date().toISOString().slice(0, 10);
  let done = 0;
  let minFutureAccessDate = null;
  let hasCurrentOrPastTimeline = false;

  entries.forEach((e) => {
    if (e.done) {
      done += 1;
      return;
    }
    if (e.accessDate) {
      if (e.accessDate <= today) {
        hasCurrentOrPastTimeline = true;
      } else if (!minFutureAccessDate || e.accessDate < minFutureAccessDate) {
        minFutureAccessDate = e.accessDate;
      }
    }
  });

  const active = total - done;

  if (done === total) {
    return { status: 'completed', startsFrom: null, done, active: 0 };
  }

  if (done === 0 && !hasCurrentOrPastTimeline && minFutureAccessDate) {
    return { status: 'scheduled', startsFrom: minFutureAccessDate, done, active };
  }

  return { status: 'ongoing', startsFrom: null, done, active };
}

/**
 * Summarize one project sheet using only the two columns confirmed present
 * across all 17 sheets: Deployment Status (done vs. not) and System Access
 * (the per-property target date, used only to classify the project's
 * overall timeline — not to flag individual rows overdue). This
 * deliberately ignores every sheet-specific column (Region, Build Type,
 * Currency Code, etc.) since those vary sheet to sheet and aren't needed
 * for a status rollup.
 */
async function getProjectStatus({ name, sheetId }) {
  try {
    const sheet = await getCachedSheet(sheetId);
    const { rows, permalink } = flattenSheet(sheet);

    const entries = rows.map((row) => ({
      done: isRowDone(row['Deployment Status']),
      accessDate: parseSmartsheetDate(row['System Access']),
    }));

    const total = rows.length;
    const { status, startsFrom, done, active } = classifyProject(entries);

    return {
      name,
      sheetId,
      sheetUrl: permalink,
      total,
      done,
      active,
      status,
      startsFrom,
      percentComplete: total > 0 ? Math.round((done / total) * 100) : 0,
      statusCounts: tallyStatusCounts(rows.map((r) => r['Deployment Status'])),
      error: null,
    };
  } catch (err) {
    // One bad/renamed/deleted sheet shouldn't take down the whole rollup.
    return {
      name,
      sheetId,
      sheetUrl: null,
      total: 0,
      done: 0,
      active: 0,
      status: 'ongoing',
      startsFrom: null,
      percentComplete: 0,
      statusCounts: {},
      error: err.message,
    };
  }
}

/**
 * RDA Rollout is already fetched + cached by hiltonRolloutSchedule.js (an
 * 8,000+ row sheet) — reuse that instead of fetching it a second time here.
 * Its rows already carry `deploymentStatus` and `systemAccessDate`, so the
 * same classification applies directly.
 *
 * NOTE: `items` here is already filtered to rows with both a Wave and a
 * System Access date (same filter the Calendar view uses), so this
 * project's `total` reflects ~6,500 "real, schedulable" rows, not the
 * full ~8,200-row raw sheet — consistent with what the Calendar tab shows,
 * not a separate undercount.
 */
async function getRdaRolloutAsProject() {
  const { items, permalink } = await getHiltonRolloutSchedule({});

  const entries = items.map((item) => ({
    done: isRowDone(item.deploymentStatus),
    accessDate: item.systemAccessDate,
  }));

  const total = items.length;
  const { status, startsFrom, done, active } = classifyProject(entries);

  return {
    name: 'RDA Rollout (Wave-based)',
    sheetId: HILTON_ROLLOUT_TRACKER_SHEET_ID,
    sheetUrl: permalink,
    total,
    done,
    active,
    status,
    startsFrom,
    percentComplete: total > 0 ? Math.round((done / total) * 100) : 0,
    statusCounts: tallyStatusCounts(items.map((i) => i.deploymentStatus)),
    error: null,
  };
}

async function getAllProjectsSummaryUncached() {
  const [sheetResults, rdaResult] = await Promise.all([
    Promise.all(getAllHiltonProjectSheets().map(getProjectStatus)),
    getRdaRolloutAsProject(),
  ]);

  const projects = [...sheetResults, rdaResult];
  const failedProjects = projects.filter((p) => p.error);

  // Project-level counts (Ongoing / Scheduled / Completed) — NOT a property
  // rollup. This is what the home-screen status ring and the top-of-panel
  // summary both read from; per-project property counts (active/done) stay
  // on each individual project card instead of being aggregated here.
  const aggregate = projects.reduce(
    (acc, p) => {
      acc[p.status] = (acc[p.status] || 0) + 1;
      return acc;
    },
    { ongoing: 0, scheduled: 0, completed: 0 }
  );

  return {
    totalProjects: projects.length,
    projects,
    aggregate,
    fetchedAt: new Date().toISOString(),
    debug: {
      failedProjectCount: failedProjects.length,
      failedProjects: failedProjects.map((p) => ({ name: p.name, sheetId: p.sheetId, error: p.error })),
    },
  };
}

const CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutes — 18 sheet fetches is heavy, and project status changes slowly

async function getAllProjectsSummary() {
  return cached('hilton-projects', CACHE_TTL_MS, getAllProjectsSummaryUncached);
}

/**
 * Project Calendar Events
 * -------------------------------------------------------------------------
 * Previously the Calendar tab and the home screen's "Scheduled Today" panel
 * only knew about the RDA Rollout wave tracker and rebuild cases — the 17
 * separate project-tracker sheets never showed up there at all, even though
 * they have their own scheduled (System Access) dates. This fills that gap:
 * one cell per (date, project) with a property count, in the same shape as
 * the rollout tracker's wave cells so WaveCalendar can render a Projects
 * row the same way it renders the Wave row.
 *
 * Every row for that day is kept — including already-Complete ones — so
 * the calendar stays a historical record of what was scheduled for a given
 * day; `completedCount` tracks how many of that cell's properties are done,
 * so the UI can show progress without losing the original scheduled total
 * when looking back at a prior week.
 *
 * RDA Rollout itself is excluded here — it already has its own dedicated
 * wave calendar via hiltonRolloutSchedule.js, so including it again would
 * double-count/double-render the same properties.
 *
 * Reuses the same per-sheet cache as getProjectStatus() (see
 * getCachedSheet above), so this doesn't add 17 extra Smartsheet calls on
 * top of the ones the Projects tab already triggers.
 */
async function getProjectScheduleUncached() {
  const perSheet = await Promise.all(
    getAllHiltonProjectSheets().map(async ({ name, sheetId }) => {
      try {
        const sheet = await getCachedSheet(sheetId);
        const { rows, permalink } = flattenSheet(sheet);
        return rows
          .map((row) => ({
            date: parseSmartsheetDate(row['System Access']),
            projectName: name,
            sheetId,
            sheetUrl: permalink,
            done: isRowDone(row['Deployment Status']),
          }))
          .filter((e) => e.date);
      } catch (err) {
        return []; // same "one bad sheet doesn't break the rollup" approach as getProjectStatus
      }
    })
  );

  const events = perSheet.flat();

  // Aggregate to (date, project) cells — same shape/purpose as
  // aggregateByDayWaveRegion() in hiltonRolloutSchedule.js.
  const map = new Map();
  events.forEach((e) => {
    const key = `${e.date}|${e.sheetId}`;
    if (!map.has(key)) {
      map.set(key, {
        date: e.date,
        projectName: e.projectName,
        sheetId: e.sheetId,
        sheetUrl: e.sheetUrl,
        propertyCount: 0,
        completedCount: 0,
      });
    }
    const cell = map.get(key);
    cell.propertyCount += 1;
    if (e.done) cell.completedCount += 1;
  });

  const cells = [...map.values()].sort((a, b) => a.date.localeCompare(b.date));

  return { cells };
}

const SCHEDULE_CACHE_TTL_MS = 10 * 60 * 1000;

/**
 * Optional `from`/`to` (ISO date strings) narrow the returned cells to a
 * window — same contract as getHiltonRolloutSchedule.
 */
async function getHiltonProjectSchedule({ from, to } = {}) {
  const { cells: allCells } = await cached('hilton-project-schedule', SCHEDULE_CACHE_TTL_MS, getProjectScheduleUncached);

  let cells = allCells;
  if (from) cells = cells.filter((c) => c.date >= from);
  if (to) cells = cells.filter((c) => c.date <= to);

  return {
    total: allCells.length,
    returnedCells: cells.length,
    fetchedAt: new Date().toISOString(),
    cells,
  };
}

module.exports = { getAllProjectsSummary, getProjectStatus, classifyProject, getHiltonProjectSchedule };
