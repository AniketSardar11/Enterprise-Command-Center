const { getSheet, flattenSheet, parseSmartsheetDate } = require('./smartsheet');
const { cached } = require('../utils/cache');
const { isRowDone } = require('../utils/deploymentStatus');

// Confirmed: HLTN_RDA_Rollout Tracker — raw per-property tracker (8,200+ rows),
// one row per property being migrated. This is the source of truth for the
// wave calendar: each row has its own "System Access" date, so grouping by
// (System Access date, Wave, Region) reproduces the day-by-day property
// counts seen in the manual calendar (e.g. different counts on different
// days within the same wave, since properties cut over on different days).
const HILTON_ROLLOUT_TRACKER_SHEET_ID = process.env.HILTON_ROLLOUT_TRACKER_SHEET_ID || '8104543993679748';

function normalizeRow(row) {
  return {
    id: String(row.rowId),
    propertyCode: row['InnCode'] || null,
    propertyName: row['Property Name'] || null,
    wave: row['Wave'] || null,
    region: row['Region'] || null,
    country: row['Country'] || null,
    brandCode: row['Brand Code'] || null,
    deploymentStatus: row['Deployment Status'] || null,
    migrationWeekMonday: parseSmartsheetDate(row['Migration Week - Monday']),
    systemAccessDate: parseSmartsheetDate(row['System Access']),
    source: 'smartsheet',
    client: 'Hilton',
  };
}

/**
 * Aggregates property-level rows into calendar-ready cells: one entry per
 * (date, wave, region) combo — this is exactly what renders as one calendar
 * cell like "Wave 16 / 31 properties AMER".
 *
 * IMPORTANT: this keeps ALL rows for that day, including already-Complete
 * ones — the calendar is a historical record of what was scheduled for
 * that day, so a completed property shouldn't vanish from a past (or even
 * current) day's cell. `completedCount` tracks how many of that cell's
 * properties are done, so the UI can show both the original total and
 * today's progress against it, without losing the "what was scheduled"
 * picture when looking back at prior weeks.
 */
function aggregateByDayWaveRegion(items, permalink) {
  const map = new Map();

  items.forEach((item) => {
    if (!item.systemAccessDate || !item.wave) return; // skip rows with no scheduled date or no wave assigned
    const key = `${item.systemAccessDate}|${item.wave}|${item.region || 'Unknown'}`;
    if (!map.has(key)) {
      map.set(key, {
        date: item.systemAccessDate,
        wave: item.wave,
        region: item.region || 'Unknown',
        propertyCount: 0,
        completedCount: 0,
        sheetUrl: permalink,
      });
    }
    const cell = map.get(key);
    cell.propertyCount += 1;
    if (isRowDone(item.deploymentStatus)) cell.completedCount += 1;
  });

  return [...map.values()].sort((a, b) => a.date.localeCompare(b.date));
}

/**
 * The genuinely expensive part: pulling and normalizing the full 8,000+ row
 * sheet. Cached for CACHE_TTL_MS so the home screen's "today" panel, the
 * Calendar tab, and any week navigation all share one fetch instead of each
 * re-pulling and re-aggregating the whole sheet from Smartsheet.
 */
async function fetchAndAggregateUncached() {
  const sheet = await getSheet(HILTON_ROLLOUT_TRACKER_SHEET_ID);
  const { columns, rows, permalink } = flattenSheet(sheet);

  const allItems = rows.map(normalizeRow).filter((item) => item.systemAccessDate && item.wave);
  const cells = aggregateByDayWaveRegion(allItems, permalink);
  const completedCount = allItems.filter((i) => isRowDone(i.deploymentStatus)).length;

  return {
    allItems,
    cells,
    permalink,
    debug: {
      sheetName: sheet.name,
      totalRawRows: rows.length,
      rowsWithValidScheduleData: allItems.length,
      completedRows: completedCount,
      columnsFound: columns,
      sampleRawRow: rows[0] || null,
    },
  };
}

const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes — this sheet doesn't need to be pulled fresh every click

/**
 * Fetch + normalize the Hilton rollout tracker for the calendar.
 * Optional `from`/`to` (ISO date strings) narrow the raw item list returned;
 * the aggregated cells always reflect the full dataset regardless, so
 * week-to-week totals stay correct even with a narrow items window.
 * The underlying sheet fetch is cached — from/to filtering itself is cheap
 * and always applied fresh against the cached data.
 */
async function getHiltonRolloutSchedule({ from, to } = {}) {
  const { allItems, cells, permalink, debug } = await cached('hilton-rollout-sheet', CACHE_TTL_MS, fetchAndAggregateUncached);

  let items = allItems;
  if (from) items = items.filter((i) => i.systemAccessDate >= from);
  if (to) items = items.filter((i) => i.systemAccessDate <= to);

  return {
    total: allItems.length,
    returnedItems: items.length,
    fetchedAt: new Date().toISOString(),
    items,
    cells,
    permalink,
    debug,
  };
}

module.exports = { getHiltonRolloutSchedule, HILTON_ROLLOUT_TRACKER_SHEET_ID };
