/**
 * Generic Client Cases
 * -------------------------------------------------------------------------
 * Hilton and Radisson each have their own service (hiltonCases.js,
 * radissonCases.js) with a hand-confirmed Reason/Subject taxonomy baked
 * into code. For a client that only has confirmed SFDC identifiers
 * (backend/config/clientIdentifiers.js) but no hand-written taxonomy yet,
 * this fetches and normalizes cases the same way, but categorizes purely
 * from whatever's been added through the admin form (Admin -> Board
 * Config -> "Add case category"). Everything starts in "Uncategorized"
 * until an admin adds categories for that client — which is the point:
 * the board goes live and shows real counts immediately, and categories
 * get refined over time through the form instead of a deploy.
 *
 * NOTE on scope: this does NOT filter by Case.Type the way Hilton's
 * BASE_WHERE does (`Type = 'Implementation'`) — that's confirmed correct
 * for Hilton specifically, unconfirmed for anyone else. This follows
 * Radisson's broader pattern instead (chain/G3 code only). If a generic
 * client's case list looks too broad (support/billing cases mixed in with
 * implementation work), that's the first thing to check — it likely needs
 * its own Type filter the same way Hilton does, at which point it may be
 * worth graduating it to its own dedicated service file.
 */

const { getField, deriveOperationalStatus, fetchClientCases } = require('./sfdcCaseFetcher');
const { buildClientWhereClause, getClientIdentifiers } = require('../config/clientIdentifiers');
const { getCaseCategoriesAsMatchers } = require('./adminConfigStore');
const { cached } = require('../utils/cache');

const DONE_SINCE = '2026-01-01T00:00:00Z';

const FIELDS = `
  Id, CaseNumber, Reason, Type, Subject, Description, Status, IsClosed,
  CreatedDate, LastModifiedDate,
  Owner.Name, CreatedBy.Name,
  Account.Name, Account.AccountNumber, Account.Client_Property_Code__c,
  Account.G3_Client_Code__c, Account.Chain_Code_Lookup__r.Name
`;

function displayName(clientKey) {
  return clientKey.charAt(0).toUpperCase() + clientKey.slice(1);
}

/** Matches admin-added categories against whichever field each one was configured for (Reason or Subject). */
function categorize(categories, record) {
  const reason = getField(record, 'Reason');
  const subject = getField(record, 'Subject');
  return categories.find((cat) => cat.matchesReason(cat.field === 'Subject' ? subject : reason));
}

function normalizeCase(clientKey, categories, record) {
  const match = categorize(categories, record);
  const status = getField(record, 'Status');

  return {
    id: getField(record, 'CaseNumber'),
    source: 'sfdc',
    client: displayName(clientKey),
    clientCode: getField(record, 'Account.G3_Client_Code__c') || null,
    chainCode: getField(record, 'Account.Chain_Code_Lookup__r.Name') || null,
    propertyCode: getField(record, 'Account.Client_Property_Code__c') || null,

    categoryKey: match ? match.key : 'uncategorized',
    categoryLabel: match ? match.label : 'Uncategorized',

    reason: getField(record, 'Reason') || null,
    type: getField(record, 'Type') || null,
    subject: getField(record, 'Subject') || null,
    description: getField(record, 'Description') || null,

    sfdcStatus: status || null,
    operationalStatus: deriveOperationalStatus(status),

    accountName: getField(record, 'Account.Name') || null,
    ownerName: getField(record, 'Owner.Name') || null,
    createdByName: getField(record, 'CreatedBy.Name') || null,

    createdDate: getField(record, 'CreatedDate') || null,
    lastModifiedDate: getField(record, 'LastModifiedDate') || null,
    isClosed: !!getField(record, 'IsClosed'),

    caseUrl: getField(record, 'Id')
      ? `https://ideas-sas.lightning.force.com/lightning/r/Case/${getField(record, 'Id')}/view`
      : null,
  };
}

async function getGenericClientCasesUncached(clientKey) {
  const identifiers = getClientIdentifiers(clientKey);
  if (!identifiers) {
    throw new Error(`No SFDC identifiers configured for "${clientKey}" — add it to backend/config/clientIdentifiers.js first.`);
  }

  const baseWhere = buildClientWhereClause(clientKey);
  const categories = getCaseCategoriesAsMatchers(clientKey);

  const { records, operationalRecordCount, doneRecordCount, doneTruncated, operationalSoqlUsed } =
    await fetchClientCases({ fields: FIELDS, baseWhere, doneSince: DONE_SINCE });

  const normalized = records.map((r) => normalizeCase(clientKey, categories, r));

  const grouped = categories.reduce((acc, cat) => {
    acc[cat.key] = { label: cat.label, description: cat.description, cases: [], counts: { active: 0, pending_client: 0, done: 0, unknown: 0 } };
    return acc;
  }, {
    uncategorized: {
      label: 'Uncategorized',
      description: 'No admin-added category matched this case yet — add one in Admin \u2192 Board Config.',
      cases: [],
      counts: { active: 0, pending_client: 0, done: 0, unknown: 0 },
    },
  });

  normalized.forEach((c) => {
    const bucket = grouped[c.categoryKey] || grouped.uncategorized;
    bucket.cases.push(c);
    bucket.counts[c.operationalStatus] = (bucket.counts[c.operationalStatus] || 0) + 1;
  });

  return {
    total: normalized.length,
    fetchedAt: new Date().toISOString(),
    cases: normalized,
    byCategory: grouped,
    doneTruncated,
    debug: {
      operationalRecordCount,
      doneRecordCount,
      doneFetchHitPageCap: doneTruncated,
      sampleRawRecord: records[0] || null,
      operationalSoqlUsed,
    },
  };
}

const CACHE_TTL_MS = 3 * 60 * 1000;

async function getGenericClientCases(clientKey) {
  return cached(`${clientKey}-cases`, CACHE_TTL_MS, () => getGenericClientCasesUncached(clientKey));
}

module.exports = { getGenericClientCases };
