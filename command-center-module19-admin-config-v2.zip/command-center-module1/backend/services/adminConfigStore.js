/**
 * Admin Config Store
 * -------------------------------------------------------------------------
 * Backs the /api/admin form: lets an admin add a new SFDC case
 * reason/category or a new Smartsheet project sheet for a client WITHOUT a
 * code change + redeploy. Everything static (Hilton's 13 categories,
 * Radisson's Subject taxonomy, the 17 Smartsheet project sheets) stays as
 * code in backend/config/ — this store only holds what's been added
 * through the admin form, and the taxonomy/registry modules merge the two
 * together at read time.
 *
 * Persistence is a flat JSON file (backend/data/adminConfig.json). That's
 * intentionally simple — single backend instance, low write volume (this
 * is an occasional admin action, not a hot path). Swap for a real DB if
 * this ever needs multi-instance writes.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_FILE = path.join(__dirname, '../data/adminConfig.json');

const EMPTY_CONFIG = { caseCategories: [], smartsheetSheets: [] };

function readConfig() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      caseCategories: Array.isArray(parsed.caseCategories) ? parsed.caseCategories : [],
      smartsheetSheets: Array.isArray(parsed.smartsheetSheets) ? parsed.smartsheetSheets : [],
    };
  } catch (err) {
    if (err.code === 'ENOENT') return { ...EMPTY_CONFIG };
    console.error('[adminConfigStore] Failed to read adminConfig.json, starting empty:', err.message);
    return { ...EMPTY_CONFIG };
  }
}

function writeConfig(config) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(config, null, 2), 'utf8');
}

function newId(prefix) {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

/**
 * Pull a numeric Smartsheet sheet ID out of either a raw ID or a full
 * Smartsheet URL. The numeric ID (from the sheet's Properties dialog, or
 * a URL containing ?sheetId=...) is what the Smartsheet API actually
 * needs — a sheet's *share link* (.../sheets/<opaque-token>) does NOT
 * contain it, so a bare share link can't be turned into a usable ID.
 * Returns null (rather than silently storing the raw input) when no
 * numeric ID can be found, so the caller can reject the submission with a
 * clear message instead of persisting a value that will just fail at
 * fetch time with a confusing error.
 */
function extractSheetId(input) {
  const trimmed = String(input || '').trim();
  const numericMatch = trimmed.match(/(\d{10,20})/);
  return numericMatch ? numericMatch[1] : null;
}

/** Case-insensitive substring or exact match, tolerant of stray whitespace. */
function buildMatcher(matchType, matchValue) {
  const needle = (matchValue || '').toLowerCase().trim();
  if (matchType === 'exact') {
    return (value) => (value || '').toLowerCase().trim() === needle;
  }
  return (value) => (value || '').toLowerCase().includes(needle);
}

// ---------------------------------------------------------------------------
// Case categories
// ---------------------------------------------------------------------------

/** @returns {Array} all admin-added categories, optionally filtered to one client. */
function getCaseCategories(clientKey) {
  const { caseCategories } = readConfig();
  return clientKey ? caseCategories.filter((c) => c.clientKey === clientKey) : caseCategories;
}

/**
 * @param {object} entry
 * @param {string} entry.clientKey    e.g. 'hilton', 'radisson'
 * @param {string} entry.clientCode   informational only (G3 code / chain code) — not used for matching
 * @param {string} entry.field        which SFDC field this category matches against, e.g. 'Reason', 'Subject'
 * @param {string} entry.label        display label shown on the category card
 * @param {string} entry.matchType    'contains' | 'exact'
 * @param {string} entry.matchValue   text to match
 * @param {string} [entry.sfdcReportUrl]  optional link to the SFDC report this category mirrors
 * @param {string} [entry.addedBy]
 */
function addCaseCategory(entry) {
  const config = readConfig();
  const key = `admin_${entry.clientKey}_${entry.label}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');

  const record = {
    id: newId('cat'),
    key,
    clientKey: entry.clientKey,
    clientCode: entry.clientCode || null,
    field: entry.field,
    label: entry.label,
    description: `Added via admin form${entry.addedBy ? ` by ${entry.addedBy}` : ''}.`,
    matchType: entry.matchType === 'exact' ? 'exact' : 'contains',
    matchValue: entry.matchValue,
    sfdcReportUrl: entry.sfdcReportUrl || null,
    addedBy: entry.addedBy || null,
    addedAt: new Date().toISOString(),
  };

  config.caseCategories.push(record);
  writeConfig(config);
  return record;
}

function removeCaseCategory(id) {
  const config = readConfig();
  const before = config.caseCategories.length;
  config.caseCategories = config.caseCategories.filter((c) => c.id !== id);
  writeConfig(config);
  return config.caseCategories.length < before;
}

/**
 * Builds category objects shaped like the static taxonomy entries
 * (`{ key, label, description, matchesReason }` etc.) so callers can
 * concat them straight onto HILTON_CASE_CATEGORIES / RADISSON_CATEGORIES
 * without special-casing dynamic ones downstream.
 */
function getCaseCategoriesAsMatchers(clientKey) {
  return getCaseCategories(clientKey).map((c) => ({
    key: c.key,
    label: c.label,
    description: c.description,
    field: c.field,
    sfdcReportUrl: c.sfdcReportUrl,
    matchesReason: buildMatcher(c.matchType, c.matchValue),
    matchesSubject: buildMatcher(c.matchType, c.matchValue),
  }));
}

// ---------------------------------------------------------------------------
// Smartsheet sheets
// ---------------------------------------------------------------------------

function getSmartsheetSheets(clientKey) {
  const { smartsheetSheets } = readConfig();
  return clientKey ? smartsheetSheets.filter((s) => s.clientKey === clientKey) : smartsheetSheets;
}

/**
 * @param {object} entry
 * @param {string} entry.clientKey
 * @param {string} entry.clientCode
 * @param {string} entry.name          display name for the project card
 * @param {string} entry.sheetIdOrUrl  raw numeric Smartsheet sheet ID, or a URL/paste containing it
 * @param {string} [entry.addedBy]
 */
function addSmartsheetSheet(entry) {
  const sheetId = extractSheetId(entry.sheetIdOrUrl);
  if (!sheetId) {
    const err = new Error(
      "Couldn't find a numeric sheet ID in that. Smartsheet share links (…/sheets/<token>) don't contain it — " +
      "open the sheet, go to File \u2192 Properties (or right-click the sheet tab \u2192 Properties), and paste the Sheet ID shown there."
    );
    err.code = 'INVALID_SHEET_ID';
    throw err;
  }

  const config = readConfig();
  const record = {
    id: newId('sheet'),
    clientKey: entry.clientKey,
    clientCode: entry.clientCode || null,
    name: entry.name,
    sheetId,
    addedBy: entry.addedBy || null,
    addedAt: new Date().toISOString(),
  };
  config.smartsheetSheets.push(record);
  writeConfig(config);
  return record;
}

function removeSmartsheetSheet(id) {
  const config = readConfig();
  const before = config.smartsheetSheets.length;
  config.smartsheetSheets = config.smartsheetSheets.filter((s) => s.id !== id);
  writeConfig(config);
  return config.smartsheetSheets.length < before;
}

/** Shaped like HILTON_PROJECT_SHEETS entries (`{ name, sheetId }`) for a straight concat. */
function getSmartsheetSheetsAsRegistryEntries(clientKey) {
  return getSmartsheetSheets(clientKey).map((s) => ({ name: s.name, sheetId: s.sheetId }));
}

module.exports = {
  readConfig,
  extractSheetId,
  getCaseCategories,
  addCaseCategory,
  removeCaseCategory,
  getCaseCategoriesAsMatchers,
  getSmartsheetSheets,
  addSmartsheetSheet,
  removeSmartsheetSheet,
  getSmartsheetSheetsAsRegistryEntries,
};
