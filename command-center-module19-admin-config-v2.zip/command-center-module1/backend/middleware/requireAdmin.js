/**
 * Admin gate for /api/admin/* routes.
 * -------------------------------------------------------------------------
 * This app has no real user-auth system yet (see README — it's an internal
 * signal board, not a login-gated product). Rather than bolt on a full
 * auth stack just to protect a handful of config-writing endpoints, this
 * checks the caller's email against a small allowlist — good enough to
 * stop a stray/accidental write from someone who isn't supposed to be
 * editing taxonomy config, not a security boundary against a hostile actor
 * on the network. If this ever needs to be real auth (SSO, etc.), swap
 * this one file out; nothing else depends on how the check is implemented.
 *
 * ADMIN_EMAILS in .env is a comma-separated allowlist. Falls back to the
 * confirmed admin if unset, so this doesn't silently lock everyone out on
 * a fresh checkout that hasn't filled in .env yet.
 */

const DEFAULT_ADMINS = ['aniket.sardar@ideas.com'];

function getAllowlist() {
  const fromEnv = process.env.ADMIN_EMAILS;
  if (!fromEnv) return DEFAULT_ADMINS;
  return fromEnv
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

function requireAdmin(req, res, next) {
  const email = (req.get('x-admin-email') || req.body?.adminEmail || '').trim().toLowerCase();

  if (!email) {
    return res.status(401).json({ error: 'Missing admin email. Send it in the x-admin-email header.' });
  }

  const allowlist = getAllowlist();
  if (!allowlist.includes(email)) {
    return res.status(403).json({ error: `${email} is not on the admin allowlist.` });
  }

  req.adminEmail = email;
  next();
}

module.exports = { requireAdmin, getAllowlist };
