const WEEKDAY_PREFIX =
  /^(Monday|Mon|Tuesday|Tue|Tues|Wednesday|Wed|Thursday|Thu|Thurs|Friday|Fri|Saturday|Sat|Sunday|Sun),?\s*/i;
const ORDINAL_SUFFIX = /(\d+)(st|nd|rd|th)/gi;

const MONTH_LOOKUP = {
  jan: 1, january: 1,
  feb: 2, february: 2,
  mar: 3, march: 3,
  apr: 4, april: 4,
  may: 5,
  jun: 6, june: 6,
  jul: 7, july: 7,
  aug: 8, august: 8,
  sep: 9, sept: 9, september: 9,
  oct: 10, october: 10,
  nov: 11, november: 11,
  dec: 12, december: 12,
};

function monthIndex(name) {
  return MONTH_LOOKUP[name.toLowerCase()] || null;
}

/**
 * Parses a loosely-formatted date string into ISO (YYYY-MM-DD), handling:
 *   "17-August-2026", "18-AUGUST-2026"
 *   "August 26, 2026", "August 25th, 2026"
 *   "08/26/2026"
 *   "Oct 5 2026" (no comma, abbreviated or full month name)
 * with an optional leading weekday ("Monday, ...") and ordinal suffixes
 * ("25th") stripped first.
 */
function parseLooseDate(rawText) {
  if (!rawText) return null;
  let text = rawText.trim();
  text = text.replace(WEEKDAY_PREFIX, '').trim();
  text = text.replace(ORDINAL_SUFFIX, '$1').trim();
  text = text.replace(/[.,]+$/, '').trim();

  // MM/DD/YYYY
  let m = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    const [, mm, dd, yyyy] = m;
    return `${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}`;
  }

  // DD-Month-YYYY  (e.g. "17-August-2026")
  m = text.match(/^(\d{1,2})-([A-Za-z]+)-(\d{4})$/);
  if (m) {
    const [, dd, monthName, yyyy] = m;
    const mm = monthIndex(monthName);
    if (mm) return `${yyyy}-${String(mm).padStart(2, '0')}-${dd.padStart(2, '0')}`;
  }

  // Month DD, YYYY  (e.g. "August 26, 2026")
  m = text.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s*(\d{4})$/);
  if (m) {
    const [, monthName, dd, yyyy] = m;
    const mm = monthIndex(monthName);
    if (mm) return `${yyyy}-${String(mm).padStart(2, '0')}-${dd.padStart(2, '0')}`;
  }

  return null;
}

/**
 * Finds `triggerRegex` in `text`, takes whatever follows up to the next
 * period/newline, and parses it as a date. Used for both Hilton
 * ("...rebuild on 17-August-2026") and Radisson ("...DATE: Monday Oct 5
 * 2026") style descriptions — same date grammar, different trigger phrase.
 */
function extractDateAfterTrigger(text, triggerRegex) {
  if (!text) return null;
  const match = text.match(triggerRegex);
  if (!match) return null;
  const afterTrigger = text.slice(match.index + match[0].length);
  const chunk = afterTrigger.match(/^\s*([^.\n]+)/);
  if (!chunk) return null;
  return parseLooseDate(chunk[1]);
}

module.exports = { parseLooseDate, extractDateAfterTrigger };
