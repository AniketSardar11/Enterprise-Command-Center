// Shared "is this row done" rule for anything keyed off the Smartsheet
// `Deployment Status` column — used by both hiltonRolloutSchedule.js (wave
// calendar cells) and hiltonProjects.js (project status rollup), so a
// property counts as complete the same way everywhere rather than each
// service defining its own slightly-different rule.
//
// Confirmed full enum (via the column filter dropdown on Hilton-461):
//   Blank, Not Started, Scheduled, In Progress, Complete, De-installed,
//   Blocked/On Hold
// "Done" = Complete or De-installed. Substring match (not exact-equals) so
// minor spelling variance across sheets ("Deinstalled", "De Installed")
// still gets caught.
const DONE_PATTERN = /complete|de-?installed/i;

function isRowDone(status) {
  if (status === null || status === undefined) return false;
  return DONE_PATTERN.test(String(status).trim());
}

module.exports = { DONE_PATTERN, isRowDone };
