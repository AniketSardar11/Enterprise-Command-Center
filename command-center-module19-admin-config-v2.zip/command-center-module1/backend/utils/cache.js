/**
 * Minimal in-memory cache with a time-to-live.
 * -------------------------------------------------------------------------
 * Not for correctness-critical data — this is purely so that repeat page
 * loads / tab switches within a short window don't each trigger a full
 * upstream fetch (2000-row paginated SFDC queries, or an 8,000+ row
 * Smartsheet pull). Single-process, in-memory: fine for one backend
 * instance; swap for Redis if this ever runs multi-instance.
 */

const store = new Map();

/**
 * Get a cached value, or compute + cache it if missing/expired.
 * @param {string} key
 * @param {number} ttlMs
 * @param {() => Promise<any>} computeFn
 */
async function cached(key, ttlMs, computeFn) {
  const hit = store.get(key);
  const now = Date.now();

  if (hit && now - hit.storedAt < ttlMs) {
    return hit.value;
  }

  const value = await computeFn();
  store.set(key, { value, storedAt: now });
  return value;
}

function invalidate(key) {
  store.delete(key);
}

module.exports = { cached, invalidate };
