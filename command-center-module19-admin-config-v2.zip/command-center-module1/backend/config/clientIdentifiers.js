/**
 * Client Identifiers
 * -------------------------------------------------------------------------
 * Different clients are identified by different Account fields in this org:
 *   - Hilton uses Account.G3_Client_Code__c = 'HILTON' (confirmed via live query)
 *   - Everyone else confirmed so far uses Account.Chain_Code_Lookup__r.Name
 *
 * A client can have more than one chain code (e.g. Venetian spans VLVG and
 * LVS). This is the single source of truth for "which SFDC accounts belong
 * to this client" — used by both the per-client case services and the
 * cross-client T-priority case pool.
 */

const CLIENT_IDENTIFIERS = {
  hilton: { g3ClientCode: 'HILTON' },

  // Confirmed from the Salesforce Account layout: Chain Code uses the
  // Chain_Code_Lookup__c is a lookup field; filters must use the related
  // Chain Code record's Name through Chain_Code_Lookup__r.Name.
  // RHGA included alongside RHAB because it appeared in the "Open RHAB RHGA
  // External Cases" T-case report title — NOT explicitly confirmed in the
  // chain-code list itself, so verify this if Radisson's T-case count looks off.
  radisson: { chainCodes: ['RHAB', 'RHGA'] },

  atlantis: { chainCodes: ['APIB'] },
  choice: { chainCodes: ['CHOI'] },
  hyatt: { chainCodes: ['HYI'] },
  marriott: { chainCodes: ['MARR'] },
  mvw: { chainCodes: ['MVW'] },
  mgm: { chainCodes: ['MGM'] },
  universal: { chainCodes: ['UNIV'] },
  venetian: { chainCodes: ['VLVG', 'LVS'] },
};

function getClientIdentifiers(clientKey) {
  return CLIENT_IDENTIFIERS[clientKey] || null;
}

/** True if a normalized case's clientCode/chainCode matches this client's identifiers. */
function matchesClient(caseRecord, clientKey) {
  const ids = getClientIdentifiers(clientKey);
  if (!ids) return false;
  if (ids.g3ClientCode && caseRecord.clientCode === ids.g3ClientCode) return true;
  if (ids.chainCodes && ids.chainCodes.includes(caseRecord.chainCode)) return true;
  return false;
}

/** Builds a SOQL WHERE fragment matching any of this client's identifiers. */
function buildClientWhereClause(clientKey) {
  const ids = getClientIdentifiers(clientKey);
  if (!ids) return null;
  const clauses = [];
  if (ids.g3ClientCode) clauses.push(`Account.G3_Client_Code__c = '${ids.g3ClientCode}'`);
  if (ids.chainCodes && ids.chainCodes.length > 0) {
    const list = ids.chainCodes.map((c) => `'${c}'`).join(', ');
    clauses.push(`Account.Chain_Code_Lookup__r.Name IN (${list})`);
  }
  return clauses.length > 0 ? `(${clauses.join(' OR ')})` : null;
}

module.exports = { CLIENT_IDENTIFIERS, getClientIdentifiers, matchesClient, buildClientWhereClause };
