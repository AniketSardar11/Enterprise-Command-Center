/**
 * "T Cases" Priority Taxonomy
 * -------------------------------------------------------------------------
 * Unlike IM cases (categorized by Case Reason), T-cases don't have a clean
 * Reason taxonomy — Reasons here are wide-ranging (Data Discrepancy,
 * Escalations, Pricing issues, etc). What actually defines a "T case" and
 * is consistent across all of them is the Priority scale itself:
 * T0, T1, T2, TS, TT0, TT1, TT2 — a completely different scale than IM's
 * (I0-I4). So T-cases are grouped by priority tier instead of by reason.
 *
 * Order is urgency-descending for display purposes — confirm this ordering
 * matches how the team actually thinks about T0 vs TT0 vs TS severity;
 * it's a reasonable guess (T-tier = standard, TT = escalated "double-T"?,
 * TS = special/urgent?) but not confirmed.
 */

const T_PRIORITY_TIERS = [
  { key: 'T0', label: 'T0', description: 'Priority T0 cases.' },
  { key: 'TT0', label: 'TT0', description: 'Priority TT0 cases (escalated?).' },
  { key: 'T1', label: 'T1', description: 'Priority T1 cases.' },
  { key: 'TT1', label: 'TT1', description: 'Priority TT1 cases (escalated?).' },
  { key: 'T2', label: 'T2', description: 'Priority T2 cases.' },
  { key: 'TT2', label: 'TT2', description: 'Priority TT2 cases (escalated?).' },
  { key: 'TS', label: 'TS', description: 'Priority TS cases (special?).' },
];

const VALID_T_PRIORITIES = T_PRIORITY_TIERS.map((t) => t.key);

function isTPriority(priority) {
  return VALID_T_PRIORITIES.includes(priority);
}

function getTierMeta(priority) {
  return T_PRIORITY_TIERS.find((t) => t.key === priority) || {
    key: priority || 'unknown',
    label: priority || 'Unknown',
    description: 'Priority value not in the expected T-tier list.',
  };
}

module.exports = { T_PRIORITY_TIERS, VALID_T_PRIORITIES, isTPriority, getTierMeta };
