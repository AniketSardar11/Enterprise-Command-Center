/**
 * Hilton Project Registry
 * -------------------------------------------------------------------------
 * Every non-template sheet in the "2026 Rollout Trackers" Smartsheet
 * workspace, confirmed via each sheet's Properties dialog. "Shelf Change
 * Template" and "Template Rollout Tracker" are excluded — they're reusable
 * templates, not real projects with actual property rows to track.
 *
 * All 17 of these sheets were confirmed (by inspection) to share two common
 * columns despite otherwise different layouts: `Deployment Status` and
 * `System Access`. That's what services/hiltonProjects.js keys off of —
 * no per-sheet custom parsing needed.
 *
 * Deployment Status confirmed (via the column filter dropdown on
 * Hilton-461) to take exactly these 7 values:
 *   Blank, Not Started, Scheduled, In Progress, Complete, De-installed,
 *   Blocked/On Hold
 * "Done" = Complete or De-installed; everything else counts as active/not-done.
 * See utils/deploymentStatus.js.
 */

const HILTON_PROJECT_SHEETS = [
  { name: 'AMER Honors Discount by DTA AgileTest | Hilton-505', sheetId: '837118883483524' },
  { name: 'Hilton-420 | EMEA.AgileUpdate Rollout Tracker', sheetId: '6359190701297540' },
  { name: 'Hilton-429 | Agile Updates Jan2026', sheetId: '429455437680516' },
  { name: 'Hilton-432 | Cost of Walk 2026', sheetId: '4827713643696004' },
  { name: 'Hilton-441 | Zero Count Room Type Change', sheetId: '4145587929698180' },
  { name: 'Hilton-442 | EMEA Shelf Change to Stabilized', sheetId: '4161697947275140' },
  { name: 'Hilton-442 | Max Agile Upload Rate Increase', sheetId: '6448830309420932' },
  { name: 'Hilton-451 | Semi Flex Updates to SPARK brand', sheetId: '8640436525551492' },
  { name: 'Hilton-461 | Aggregate Data Refresh February 2026', sheetId: '7540655506018180' },
  { name: 'Hilton-464 | Extra Adult Pricing', sheetId: '4065422262357892' },
  { name: 'Hilton-484 | EMEA Agile Template Update', sheetId: '7565457421717380' },
  { name: 'Hilton-488 | AMER Same Shelf Change (Advanced Purchase)', sheetId: '7252456923680644' },
  { name: 'Hilton-492 | Aggregate Data Refresh April 2026', sheetId: '6497344924110724' },
  { name: 'Hilton-496 | Demand Driven Pricing', sheetId: '8978512307244932' },
  { name: 'Hilton-515 | APAC Honors Discount DTA Agile Test', sheetId: '4068303390592900' },
  { name: 'Hilton-516 | EAME Honors Discount DTA Agile Test', sheetId: '4934591625252740' },
  { name: 'Hilton-520 | Extra Adult Pricing', sheetId: '1755172685434756' },
];

// Sheets added through the admin form (Admin Config -> "Add Smartsheet
// project", clientKey 'hilton') get appended here so a newly-pasted sheet
// ID shows up on the Projects tab without a code change. Read fresh each
// call (not cached at module load) so it reflects the latest admin edits.
function getAllHiltonProjectSheets() {
  const { getSmartsheetSheetsAsRegistryEntries } = require('../services/adminConfigStore');
  return [...HILTON_PROJECT_SHEETS, ...getSmartsheetSheetsAsRegistryEntries('hilton')];
}

module.exports = { HILTON_PROJECT_SHEETS, getAllHiltonProjectSheets };
