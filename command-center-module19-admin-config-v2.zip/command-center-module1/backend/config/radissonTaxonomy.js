/**
 * Radisson Case Taxonomy
 * -------------------------------------------------------------------------
 * Unlike Hilton (categorized by the standard `Reason` field), Radisson's
 * own SFDC reports categorize by exact `Subject` text match, confirmed
 * directly from their report filter panels and the client's own mapping
 * sheet (2026-09):
 *   - "Installation" — Subject IN ('Radisson Agent Install', 'Radisson HTNG
 *     Install', 'Radisson OHIP Install', 'G3 Synthetic History Build
 *     Property Installation', 'G3 Standard Build Property Installation')
 *   - "Upload" — Subject = 'G3 Decision Upload'
 *   - "Rebuild" — Subject = 'Radisson LDB to STD Build' OR 'G3 Synthetic
 *     History Build to STD Build'
 *
 * Note the near-identical names but distinct meanings: "G3 Synthetic
 * History Build Property Installation" (Installation) vs "G3 Synthetic
 * History Build to STD Build" (Rebuild) — exact match only, no prefix
 * matching, to avoid conflating the two.
 */

const RADISSON_CATEGORIES = [
  {
    key: 'install',
    label: 'Installation',
    matchesSubject: (s) =>
      [
        'Radisson Agent Install',
        'Radisson HTNG Install',
        'Radisson OHIP Install',
        'G3 Synthetic History Build Property Installation',
        'G3 Standard Build Property Installation',
      ].includes(s),
    description: 'New property installation cases (Agent, HTNG, OHIP, and Synthetic/Standard Build installs).',
  },
  {
    key: 'upload',
    label: 'Upload (G3 Decision)',
    matchesSubject: (s) => s === 'G3 Decision Upload',
    description: 'G3 Decision Upload cases.',
  },
  {
    key: 'rebuild',
    label: 'LDB to Standard Rebuild',
    matchesSubject: (s) =>
      s === 'Radisson LDB to STD Build' || s === 'G3 Synthetic History Build to STD Build',
    description: 'Property rebuild from LDB/Synthetic history to Standard build.',
  },
];

// Same admin-form merge as Hilton's caseTaxonomy.js — see the comment
// there. Radisson categorizes by Subject rather than Reason, so an
// admin-added Radisson category's matchValue is tested against Subject
// (matchesSubject), not Reason.
function getAllRadissonCategories() {
  const { getCaseCategoriesAsMatchers } = require('../services/adminConfigStore');
  return [...RADISSON_CATEGORIES, ...getCaseCategoriesAsMatchers('radisson')];
}

function categorizeBySubject(subject) {
  if (!subject) return 'uncategorized';
  const match = getAllRadissonCategories().find((cat) => cat.matchesSubject(subject));
  return match ? match.key : 'uncategorized';
}

function getCategoryMeta(key) {
  return getAllRadissonCategories().find((c) => c.key === key) || {
    key: 'uncategorized',
    label: 'Uncategorized',
    description: 'Subject did not match Installation, Upload, or Rebuild — a genuinely new case type worth checking.',
  };
}

module.exports = { RADISSON_CATEGORIES, getAllRadissonCategories, categorizeBySubject, getCategoryMeta };
