/**
 * Hilton Case Taxonomy
 * -------------------------------------------------------------------------
 * Maps the SFDC standard field `Reason` (Case Reason) to the 12 categories
 * your team tracks daily via Salesforce reports.
 *
 * IMPORTANT: Real Reason values turned out to be COMPOUND strings, e.g.
 * "Synthetic Data Build - Configuration File" or
 * "Limited Data Build - Recalibration" — not bare category names as first
 * guessed. There's also a data-quality quirk: at least one case uses an
 * en-dash (–) instead of a hyphen (-) between the two halves.
 *
 * So instead of exact matching, each category defines `matchesReason(reason)`
 * — a substring/pattern test — which is robust to the "Synthetic Data Build"
 * vs "Limited Data Build" (LDB) prefix and to punctuation inconsistencies.
 */

function normalize(str) {
  return (str || '')
    .toLowerCase()
    .replace(/–/g, '-'); // normalize en-dash to hyphen
}

const HILTON_CASE_CATEGORIES = [
  {
    key: 'configuration_file',
    label: 'Configuration File',
    matchesReason: (r) => normalize(r).includes('configuration file'),
    description: 'Initial configuration file received for a new property.',
  },
  {
    key: 'setup',
    label: 'Setup (SRP / LDB / Synthetic Data Build)',
    matchesReason: (r) => {
      const n = normalize(r);
      return (n.includes('property setup') || n === 'property setup') && !n.includes('rebuild');
    },
    description: 'Data collection & population — the install step (includes Extended Stay variants).',
  },
  {
    key: 'de_install',
    label: 'De-Install',
    matchesReason: (r) => normalize(r).includes('de-install') || normalize(r).includes('deinstall'),
    description: 'Property removal.',
  },
  {
    key: 'delete_property',
    label: 'Delete Property',
    matchesReason: (r) => normalize(r).includes('delete property'),
    description: 'Full removal from system (distinct from de-install).',
  },
  {
    key: 'delphi_install',
    label: 'Delphi.fdc Install',
    matchesReason: (r) => normalize(r).includes('delphi'),
    description: 'Legacy interface install type. Mostly historical/closed volume.',
  },
  {
    key: 'str_activation',
    label: 'STR Activation',
    matchesReason: (r) => normalize(r).includes('str activation'),
    description: 'STR census data input configuration for a property.',
  },
  {
    key: 'rate_shopping_vendor_switch',
    label: 'Rate Shopping Vendor Switch',
    matchesReason: (r) => normalize(r).includes('rate shopping vendor switch'),
    description: 'Existing property switching rate shopping vendor.',
  },
  {
    key: 'rate_shopping',
    label: 'Rate Shopping (New Setup)',
    // checked AFTER vendor-switch above, since "rate shopping vendor switch" also contains "rate shopping"
    matchesReason: (r) => normalize(r).includes('rate shopping'),
    description: 'New rate shopping subscription/integration setup.',
  },
  {
    key: 'ldb_standard_switch',
    label: 'LDB to Standard Switch',
    matchesReason: (r) => normalize(r).includes('rebuild to standard'),
    description: 'Data build type conversion / property rebuild.',
  },
  {
    key: 'run_ldb_process',
    label: 'Run LDB / Data Build Process',
    matchesReason: (r) => normalize(r).includes('run ldb process') || normalize(r).includes('run synthetic data build process'),
    description: 'Manual trigger to run the data build process for a property.',
  },
  {
    key: 'recalibration',
    label: 'LDB Recalibration',
    matchesReason: (r) => normalize(r).includes('recalibration'),
    description: 'Unlock / re-run request for a property already built.',
  },
  {
    key: 'demand360',
    label: 'Demand360 (Add/Remove)',
    matchesReason: (r) => normalize(r).includes('demand360'),
    description: 'Demand360 add-on install or removal.',
  },
  {
    key: 'service_request',
    label: 'Service Request',
    matchesReason: (r) => normalize(r).includes('service request'),
    description: 'General configuration/service request, potentially billable.',
  },
];

// Categories added through the admin form (Admin Config -> "Add case
// category", clientKey 'hilton') get merged in here so they behave exactly
// like the hand-written ones above: they show up as their own category
// card and participate in categorization. Read fresh on every call rather
// than cached at module-load time, since an admin-added category should
// take effect on the next request, not the next backend restart.
function getAllHiltonCategories() {
  const { getCaseCategoriesAsMatchers } = require('../services/adminConfigStore');
  return [...HILTON_CASE_CATEGORIES, ...getCaseCategoriesAsMatchers('hilton')];
}

function categorizeByReason(reason) {
  if (!reason) return 'uncategorized';
  const match = getAllHiltonCategories().find((cat) => cat.matchesReason(reason));
  return match ? match.key : 'uncategorized';
}

function getCategoryMeta(key) {
  return getAllHiltonCategories().find((c) => c.key === key) || {
    key: 'uncategorized',
    label: 'Uncategorized',
    description: 'Case Reason did not match a known category — needs mapping.',
  };
}

module.exports = {
  HILTON_CASE_CATEGORIES,
  getAllHiltonCategories,
  categorizeByReason,
  getCategoryMeta,
};
