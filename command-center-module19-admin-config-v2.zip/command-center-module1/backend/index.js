require('dotenv').config();
const express = require('express');
const hltnRouter = require('./routes/hltn');
const deploymentsRouter = require('./routes/deployments');
const rebuildScheduleRouter = require('./routes/rebuildSchedule');
const rolloutScheduleRouter = require('./routes/rolloutSchedule');
const priorityCasesRouter = require('./routes/priorityCases');
const projectsRouter = require('./routes/projects');
const radissonRouter = require('./routes/radisson');
const adminRouter = require('./routes/admin');
const genericClientRouter = require('./routes/genericClient');

const app = express();
app.use(express.json());

app.use('/api/hltn', hltnRouter);
app.use('/api/hltn', deploymentsRouter);
app.use('/api/hltn', rebuildScheduleRouter);
app.use('/api/hltn', rolloutScheduleRouter);
app.use('/api/hltn', priorityCasesRouter);
app.use('/api/hltn', projectsRouter);
app.use('/api/radisson', radissonRouter);
app.use('/api/admin', adminRouter);
app.use('/api/clients', genericClientRouter);

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

const PORT = process.env.PORT || 4001; // separate port from friend's existing :4000 backend
app.listen(PORT, () => {
  console.log(`Command Center backend (Module 1+2: Hilton cases + deployments) running on port ${PORT}`);
});
