const express = require('express');
const { getAllProjectsSummary, getHiltonProjectSchedule } = require('../services/hiltonProjects');

const router = express.Router();

// GET /api/hltn/projects -> per-project status (ongoing/scheduled/completed)
// + project-level aggregate counts across all 17 rollout-tracker sheets
// plus the RDA wave tracker. No property-level "overdue" concept here —
// see services/hiltonProjects.js for the Ongoing/Scheduled/Completed
// classification logic.
router.get('/projects', async (req, res) => {
  try {
    const data = await getAllProjectsSummary();
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/projects]', err.message);
    res.status(502).json({ error: 'Failed to fetch project summary', detail: err.message });
  }
});

// GET /api/hltn/project-schedule?from=&to=
// -> (date, project) calendar cells for the 17 project-tracker sheets
// (RDA Rollout excluded — it already has its own /rollout-schedule feed),
// so scheduled project work shows up in the Calendar tab and in the home
// screen's "Scheduled Today" panel, not just Hilton's wave rollout.
router.get('/project-schedule', async (req, res) => {
  try {
    const { from, to } = req.query;
    const data = await getHiltonProjectSchedule({ from, to });
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/project-schedule]', err.message);
    res.status(502).json({ error: 'Failed to fetch project schedule', detail: err.message });
  }
});

module.exports = router;
