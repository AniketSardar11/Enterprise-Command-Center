const express = require('express');
const { getHiltonCases } = require('../services/hiltonCases');

const router = express.Router();

// GET /api/hltn/cases -> full normalized + grouped Hilton case data
router.get('/cases', async (req, res) => {
  try {
    const data = await getHiltonCases();
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/cases]', err.message);
    res.status(502).json({ error: 'Failed to fetch Hilton cases', detail: err.message });
  }
});

// GET /api/hltn/cases/:categoryKey -> just one category (e.g. /configuration_file)
router.get('/cases/:categoryKey', async (req, res) => {
  try {
    const data = await getHiltonCases();
    const bucket = data.byCategory[req.params.categoryKey];
    if (!bucket) {
      return res.status(404).json({ error: `Unknown category: ${req.params.categoryKey}` });
    }
    res.json({ fetchedAt: data.fetchedAt, categoryKey: req.params.categoryKey, ...bucket });
  } catch (err) {
    console.error('[GET /api/hltn/cases/:categoryKey]', err.message);
    res.status(502).json({ error: 'Failed to fetch Hilton cases', detail: err.message });
  }
});

module.exports = router;
