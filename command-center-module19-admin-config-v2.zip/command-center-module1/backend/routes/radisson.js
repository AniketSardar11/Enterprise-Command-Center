const express = require('express');
const { getRadissonCases, getRadissonRebuildSchedule } = require('../services/radissonCases');
const { getPriorityCasesForClient } = require('../services/priorityCases');

const router = express.Router();

router.get('/cases', async (req, res) => {
  try {
    const data = await getRadissonCases();
    res.json(data);
  } catch (err) {
    console.error('[GET /api/radisson/cases]', err.message);
    res.status(502).json({ error: 'Failed to fetch Radisson cases', detail: err.message });
  }
});

router.get('/rebuild-schedule', async (req, res) => {
  try {
    const data = await getRadissonRebuildSchedule();
    res.json(data);
  } catch (err) {
    console.error('[GET /api/radisson/rebuild-schedule]', err.message);
    res.status(502).json({ error: 'Failed to fetch Radisson rebuild schedule', detail: err.message });
  }
});

// GET /api/radisson/priority-cases -> Radisson's T-priority cases, matched via
// Chain_Code_Lookup__c IN ('RHAB', 'RHGA') against the same cross-client
// T-case pool Hilton uses (see services/priorityCases.js).
router.get('/priority-cases', async (req, res) => {
  try {
    const data = await getPriorityCasesForClient('radisson');
    res.json(data);
  } catch (err) {
    console.error('[GET /api/radisson/priority-cases]', err.message);
    res.status(502).json({ error: 'Failed to fetch Radisson priority (T) cases', detail: err.message });
  }
});

module.exports = router;
