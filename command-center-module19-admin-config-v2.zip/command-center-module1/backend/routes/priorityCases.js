const express = require('express');
const { getPriorityCasesForClient } = require('../services/priorityCases');

const router = express.Router();

// GET /api/hltn/priority-cases -> Hilton's T-priority cases, grouped by tier.
// The underlying service pulls cross-client (see services/priorityCases.js)
// but this route scopes to Hilton, matching the existing /api/hltn/* pattern.
router.get('/priority-cases', async (req, res) => {
  try {
    const data = await getPriorityCasesForClient('hilton');
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/priority-cases]', err.message);
    res.status(502).json({ error: 'Failed to fetch priority (T) cases', detail: err.message });
  }
});

module.exports = router;
