const express = require('express');
const { getHiltonDeployments } = require('../services/hiltonDeployments');

const router = express.Router();

// GET /api/hltn/deployments -> planned deployment waves for the calendar view
router.get('/deployments', async (req, res) => {
  try {
    const data = await getHiltonDeployments();
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/deployments]', err.message);
    res.status(502).json({ error: 'Failed to fetch deployment calendar data', detail: err.message });
  }
});

module.exports = router;
