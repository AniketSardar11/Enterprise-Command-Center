const express = require('express');
const { getHiltonRolloutSchedule } = require('../services/hiltonRolloutSchedule');

const router = express.Router();

// GET /api/hltn/rollout-schedule?from=YYYY-MM-DD&to=YYYY-MM-DD
// -> wave calendar data derived from the HLTN_RDA_Rollout Tracker sheet.
// `cells` is the pre-aggregated (date, wave, region, propertyCount) list the
// calendar actually renders; `items` is the (optionally date-filtered) raw
// per-property list for drill-in.
router.get('/rollout-schedule', async (req, res) => {
  try {
    const { from, to } = req.query;
    const data = await getHiltonRolloutSchedule({ from, to });
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/rollout-schedule]', err.message);
    res.status(502).json({ error: 'Failed to fetch rollout schedule', detail: err.message });
  }
});

module.exports = router;
