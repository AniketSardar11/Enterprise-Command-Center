const express = require('express');
const { getGenericClientCases } = require('../services/genericCases');
const { getGenericProjectsSummary } = require('../services/genericProjects');
const { CLIENT_IDENTIFIERS } = require('../config/clientIdentifiers');

const router = express.Router();

function requireKnownClient(req, res, next) {
  if (!CLIENT_IDENTIFIERS[req.params.clientKey]) {
    return res.status(404).json({
      error: `No SFDC identifiers configured for "${req.params.clientKey}" — add it to backend/config/clientIdentifiers.js first.`,
    });
  }
  next();
}

// GET /api/clients/:clientKey/cases -> same shape as /api/hltn/cases, categorized
// entirely from admin-added categories for this client.
router.get('/:clientKey/cases', requireKnownClient, async (req, res) => {
  try {
    const data = await getGenericClientCases(req.params.clientKey);
    res.json(data);
  } catch (err) {
    console.error(`[GET /api/clients/${req.params.clientKey}/cases]`, err.message);
    res.status(502).json({ error: `Failed to fetch ${req.params.clientKey} cases`, detail: err.message });
  }
});

// GET /api/clients/:clientKey/projects -> same shape as /api/hilton/projects,
// backed entirely by admin-added Smartsheet sheets for this client.
router.get('/:clientKey/projects', requireKnownClient, async (req, res) => {
  try {
    const data = await getGenericProjectsSummary(req.params.clientKey);
    res.json(data);
  } catch (err) {
    console.error(`[GET /api/clients/${req.params.clientKey}/projects]`, err.message);
    res.status(502).json({ error: `Failed to fetch ${req.params.clientKey} projects`, detail: err.message });
  }
});

module.exports = router;
