const express = require('express');
const { requireAdmin } = require('../middleware/requireAdmin');
const adminConfigStore = require('../services/adminConfigStore');
const { invalidate } = require('../utils/cache');

const router = express.Router();

router.use(requireAdmin);

// GET /api/admin/config -> everything added via the admin form so far,
// for the admin panel's "currently added" list.
router.get('/config', (req, res) => {
  res.json(adminConfigStore.readConfig());
});

// POST /api/admin/case-categories
// body: { clientKey, clientCode, field, label, matchType, matchValue, sfdcReportUrl }
// Adds a new case reason/category for a client's board. Takes effect on
// the NEXT fetch — no restart needed — but the relevant client's SFDC
// cache may still be serving a slightly stale grouping for up to its TTL
// (3 min for Hilton/Radisson cases); invalidated below so it's immediate.
router.post('/case-categories', (req, res) => {
  const { clientKey, clientCode, field, label, matchType, matchValue, sfdcReportUrl } = req.body || {};

  if (!clientKey || !field || !label || !matchValue) {
    return res.status(400).json({ error: 'clientKey, field, label, and matchValue are required.' });
  }

  const record = adminConfigStore.addCaseCategory({
    clientKey,
    clientCode,
    field,
    label,
    matchType,
    matchValue,
    sfdcReportUrl,
    addedBy: req.adminEmail,
  });

  // Cases are cached per client (hilton-cases / radisson-cases) — clear so
  // the new category shows up on the next board load instead of waiting
  // out the TTL.
  invalidate(`${clientKey}-cases`);

  res.status(201).json(record);
});

router.delete('/case-categories/:id', (req, res) => {
  const removed = adminConfigStore.removeCaseCategory(req.params.id);
  if (!removed) return res.status(404).json({ error: 'No case category with that id.' });

  const { clientKey } = req.query;
  if (clientKey) invalidate(`${clientKey}-cases`);

  res.json({ ok: true });
});

// POST /api/admin/smartsheet-sheets
// body: { clientKey, clientCode, name, sheetIdOrUrl }
// Adds a new Smartsheet project sheet to a client's Projects tab. Paste
// either the raw numeric sheet ID (from the sheet's Properties dialog) or
// a URL/text containing it — extractSheetId pulls the number out either way.
router.post('/smartsheet-sheets', (req, res) => {
  const { clientKey, clientCode, name, sheetIdOrUrl } = req.body || {};

  if (!clientKey || !name || !sheetIdOrUrl) {
    return res.status(400).json({ error: 'clientKey, name, and sheetIdOrUrl are required.' });
  }

  let record;
  try {
    record = adminConfigStore.addSmartsheetSheet({
      clientKey,
      clientCode,
      name,
      sheetIdOrUrl,
      addedBy: req.adminEmail,
    });
  } catch (err) {
    if (err.code === 'INVALID_SHEET_ID') {
      return res.status(400).json({ error: err.message });
    }
    throw err;
  }

  // Project summary/schedule are cached under fixed keys today (Hilton-only
  // — see services/hiltonProjects.js); clear both so a newly-added sheet
  // shows up right away rather than after the 10-minute TTL.
  invalidate(`${clientKey}-projects`);
  invalidate(`${clientKey}-project-schedule`);

  res.status(201).json(record);
});

router.delete('/smartsheet-sheets/:id', (req, res) => {
  const removed = adminConfigStore.removeSmartsheetSheet(req.params.id);
  if (!removed) return res.status(404).json({ error: 'No Smartsheet entry with that id.' });

  const { clientKey } = req.query;
  if (clientKey) {
    invalidate(`${clientKey}-projects`);
    invalidate(`${clientKey}-project-schedule`);
  }

  res.json({ ok: true });
});

module.exports = router;
