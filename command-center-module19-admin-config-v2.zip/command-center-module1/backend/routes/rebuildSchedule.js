const express = require('express');
const { getHiltonRebuildSchedule } = require('../services/hiltonRebuildSchedule');

const router = express.Router();

// GET /api/hltn/rebuild-schedule -> LDB-to-Standard rebuild cases with scheduled dates
// parsed from their description, for the deployment calendar's "Rebuild" row.
router.get('/rebuild-schedule', async (req, res) => {
  try {
    const data = await getHiltonRebuildSchedule();
    res.json(data);
  } catch (err) {
    console.error('[GET /api/hltn/rebuild-schedule]', err.message);
    res.status(502).json({ error: 'Failed to fetch rebuild schedule', detail: err.message });
  }
});

module.exports = router;
