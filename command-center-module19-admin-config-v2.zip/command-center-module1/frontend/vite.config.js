import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Backend (Module 1: Hilton cases) runs on :4001 — see backend/.env.example
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:4001',
        changeOrigin: true,
      },
    },
  },
});
