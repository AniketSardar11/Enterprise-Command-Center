import { useState } from 'react';
import Masthead from './components/Masthead';
import EnterpriseHome from './components/EnterpriseHome';
import ClientBoard from './components/ClientBoard';
import AdminPanel from './components/AdminPanel';
import { useHiltonCases } from './hooks/useHiltonCases';
import { useHiltonPriorityCases } from './hooks/useHiltonPriorityCases';
import { useHiltonProjects } from './hooks/useHiltonProjects';
import { useRadissonCases } from './hooks/useRadissonCases';
import { useRadissonPriorityCases } from './hooks/useRadissonPriorityCases';
import { useGenericClients } from './hooks/useGenericClients';
import { CLIENTS, getClient } from './data/clients';

// Any live client other than Hilton/Radisson goes through the generic
// hook — see useGenericClients.js. Adding a new live client is a
// data/clients.js edit, not a new hook.
const GENERIC_LIVE_CLIENT_KEYS = CLIENTS.filter((c) => c.live && c.key !== 'hilton' && c.key !== 'radisson').map(
  (c) => c.key
);

const EMPTY_GENERIC_ENTRY = { data: null, projectsData: null, error: null, loading: false, lastFetchedAt: null, refresh: () => {} };

// Maps a client key to the hook results that feed its board's "im" and "t"
// tabs. Every new live client with its own dedicated service adds one line
// here; anything else falls through to the generic hook's data.
function useClientData(hilton, hiltonPriority, radisson, radissonPriority, generic, clientKey) {
  if (clientKey === 'radisson') return { im: radisson, priority: radissonPriority };
  if (clientKey === 'hilton') return { im: hilton, priority: hiltonPriority };
  const entry = generic.byClient[clientKey] || EMPTY_GENERIC_ENTRY;
  return {
    im: { data: entry.data, error: entry.error, loading: entry.loading, lastFetchedAt: entry.lastFetchedAt, refresh: generic.refresh },
    // No generic client has T-priority cases wired up yet (capabilities.t
    // stays false until confirmed) — ClientBoard hides that tab, so this
    // stub just needs to not crash if it's ever read.
    priority: { data: null, error: null, loading: false, lastFetchedAt: null, refresh: () => {} },
  };
}

export default function App() {
  const [clientKey, setClientKey] = useState(null); // null = home
  const [initialTab, setInitialTab] = useState('cases');
  const [adminOpen, setAdminOpen] = useState(false);

  // These hooks stay mounted at the top level so the home tiles and each
  // client's board share one live subscription instead of double-fetching.
  const hilton = useHiltonCases();
  const hiltonPriority = useHiltonPriorityCases();
  const hiltonProjects = useHiltonProjects();
  const radisson = useRadissonCases();
  const radissonPriority = useRadissonPriorityCases();

  const client = clientKey ? getClient(clientKey) : null;
  const generic = useGenericClients(GENERIC_LIVE_CLIENT_KEYS);
  const { im, priority } = useClientData(hilton, hiltonPriority, radisson, radissonPriority, generic, clientKey);

  const openClient = (key, tab = 'cases') => {
    setInitialTab(tab);
    setClientKey(key);
  };

  if (client && client.live) {
    const isHilton = clientKey === 'hilton';
    const genericEntry = generic.byClient[clientKey] || EMPTY_GENERIC_ENTRY;
    const projects = isHilton
      ? { data: hiltonProjects.data, error: hiltonProjects.error, loading: hiltonProjects.loading, refresh: hiltonProjects.refresh }
      : { data: genericEntry.projectsData, error: null, loading: genericEntry.loading, refresh: generic.refresh };

    return (
      <ClientBoard
        client={client}
        data={im.data}
        error={im.error}
        loading={im.loading}
        lastFetchedAt={im.lastFetchedAt}
        refresh={im.refresh}
        priorityData={priority.data}
        priorityError={priority.error}
        priorityLoading={priority.loading}
        priorityRefresh={priority.refresh}
        projectsData={projects.data}
        projectsError={projects.error}
        projectsLoading={projects.loading}
        projectsRefresh={projects.refresh}
        initialTab={initialTab}
        onBack={() => setClientKey(null)}
      />
    );
  }

  return (
    <div className="app">
      <Masthead
        title="Enterprise Command Center"
        lastFetchedAt={hilton.lastFetchedAt}
        hasError={!!hilton.error}
        loading={hilton.loading}
        onOpenAdmin={() => setAdminOpen(true)}
      />
      <EnterpriseHome
        hiltonData={hilton.data}
        hiltonLoading={hilton.loading}
        hiltonPriorityData={hiltonPriority.data}
        hiltonPriorityLoading={hiltonPriority.loading}
        hiltonProjectsData={hiltonProjects.data}
        hiltonProjectsLoading={hiltonProjects.loading}
        radissonData={radisson.data}
        radissonLoading={radisson.loading}
        radissonPriorityData={radissonPriority.data}
        radissonPriorityLoading={radissonPriority.loading}
        genericByClient={generic.byClient}
        onOpenClient={openClient}
      />
      {adminOpen && <AdminPanel onClose={() => setAdminOpen(false)} />}
    </div>
  );
}
