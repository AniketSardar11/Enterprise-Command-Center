// Thin fetch wrapper around the Module 1 (Hilton) backend.
// In dev, vite.config.js proxies /api -> http://localhost:4001.
// In prod, set VITE_API_BASE to the deployed backend origin.

const API_BASE = import.meta.env.VITE_API_BASE || '';

async function request(path) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { Accept: 'application/json' },
  });

  if (!res.ok) {
    let detail = '';
    try {
      const body = await res.json();
      detail = body.detail || body.error || '';
    } catch {
      // response wasn't JSON — ignore
    }
    const err = new Error(detail || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }

  return res.json();
}

/** GET /api/hltn/cases -> { total, fetchedAt, cases, byCategory, doneTruncated, debug } */
export function fetchHiltonCases() {
  return request('/api/hltn/cases');
}

/** GET /api/hltn/rollout-schedule?from=&to= -> { total, cells, items, debug } */
export function fetchHiltonRolloutSchedule(from, to) {
  const params = new URLSearchParams();
  if (from) params.set('from', from);
  if (to) params.set('to', to);
  const qs = params.toString();
  return request(`/api/hltn/rollout-schedule${qs ? `?${qs}` : ''}`);
}

/** GET /api/hltn/rebuild-schedule -> { total, items, debug } */
export function fetchHiltonRebuildSchedule() {
  return request('/api/hltn/rebuild-schedule');
}

/** GET /api/hltn/priority-cases -> { total, fetchedAt, cases, byPriority, doneTruncated, debug } */
export function fetchHiltonPriorityCases() {
  return request('/api/hltn/priority-cases');
}

/** GET /api/hltn/projects -> { totalProjects, projects, aggregate, fetchedAt, debug } */
export function fetchHiltonProjects() {
  return request('/api/hltn/projects');
}

/** GET /api/hltn/project-schedule?from=&to= -> { total, cells, fetchedAt } */
export function fetchHiltonProjectSchedule(from, to) {
  const params = new URLSearchParams();
  if (from) params.set('from', from);
  if (to) params.set('to', to);
  const qs = params.toString();
  return request(`/api/hltn/project-schedule${qs ? `?${qs}` : ''}`);
}

/** GET /api/radisson/cases -> { total, fetchedAt, cases, byCategory, doneTruncated, debug } */
export function fetchRadissonCases() {
  return request('/api/radisson/cases');
}

/** GET /api/radisson/rebuild-schedule -> { total, items, debug } */
export function fetchRadissonRebuildSchedule() {
  return request('/api/radisson/rebuild-schedule');
}

/** GET /api/radisson/priority-cases -> { total, fetchedAt, cases, byPriority, doneTruncated, debug } */
export function fetchRadissonPriorityCases() {
  return request('/api/radisson/priority-cases');
}

// ---------------------------------------------------------------------------
// Generic client cases/projects — for any client with confirmed SFDC
// identifiers (backend/config/clientIdentifiers.js) but no dedicated
// hand-written service. Categories/sheets come entirely from the admin form.
// ---------------------------------------------------------------------------

/** GET /api/clients/:clientKey/cases -> same shape as fetchHiltonCases */
export function fetchGenericClientCases(clientKey) {
  return request(`/api/clients/${clientKey}/cases`);
}

/** GET /api/clients/:clientKey/projects -> same shape as fetchHiltonProjects */
export function fetchGenericClientProjects(clientKey) {
  return request(`/api/clients/${clientKey}/projects`);
}

// ---------------------------------------------------------------------------
// Admin config (Admin panel) — adding case categories / Smartsheet sheets
// for a client without a code change. Every call here sends the admin's
// email in x-admin-email; the backend checks it against ADMIN_EMAILS and
// responds 401 (missing) / 403 (not allowed) if it isn't recognized.
// ---------------------------------------------------------------------------

async function adminRequest(path, { method = 'GET', adminEmail, body } = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'x-admin-email': adminEmail || '',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  let payload = null;
  try {
    payload = await res.json();
  } catch {
    // no JSON body — leave payload null
  }

  if (!res.ok) {
    const err = new Error((payload && payload.error) || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }

  return payload;
}

/** GET /api/admin/config -> { caseCategories, smartsheetSheets } */
export function fetchAdminConfig(adminEmail) {
  return adminRequest('/api/admin/config', { adminEmail });
}

/** POST /api/admin/case-categories */
export function addCaseCategory(adminEmail, payload) {
  return adminRequest('/api/admin/case-categories', { method: 'POST', adminEmail, body: payload });
}

/** DELETE /api/admin/case-categories/:id?clientKey= */
export function deleteCaseCategory(adminEmail, id, clientKey) {
  return adminRequest(`/api/admin/case-categories/${id}?clientKey=${encodeURIComponent(clientKey)}`, {
    method: 'DELETE',
    adminEmail,
  });
}

/** POST /api/admin/smartsheet-sheets */
export function addSmartsheetSheet(adminEmail, payload) {
  return adminRequest('/api/admin/smartsheet-sheets', { method: 'POST', adminEmail, body: payload });
}

/** DELETE /api/admin/smartsheet-sheets/:id?clientKey= */
export function deleteSmartsheetSheet(adminEmail, id, clientKey) {
  return adminRequest(`/api/admin/smartsheet-sheets/${id}?clientKey=${encodeURIComponent(clientKey)}`, {
    method: 'DELETE',
    adminEmail,
  });
}
