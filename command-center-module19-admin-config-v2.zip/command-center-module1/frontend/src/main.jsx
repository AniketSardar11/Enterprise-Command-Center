import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import { OverdueProvider } from './context/OverdueContext.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <OverdueProvider>
      <App />
    </OverdueProvider>
  </React.StrictMode>
);
