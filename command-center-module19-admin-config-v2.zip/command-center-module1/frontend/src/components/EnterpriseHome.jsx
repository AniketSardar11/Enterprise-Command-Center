import { useMemo } from 'react';
import { CalendarClock, ArrowUpRight } from 'lucide-react';
import { CLIENTS } from '../data/clients';
import ClientTile from './ClientTile';
import { tally } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';
import { useTodayActivity } from '../hooks/useTodayActivity';

export default function EnterpriseHome({
  hiltonData,
  hiltonLoading,
  hiltonPriorityData,
  hiltonPriorityLoading,
  hiltonProjectsData,
  hiltonProjectsLoading,
  radissonData,
  radissonLoading,
  radissonPriorityData,
  radissonPriorityLoading,
  genericByClient = {},
  onOpenClient,
}) {
  const { reviewedIds } = useOverdueOverrides();
  const { waves, rebuilds, projects, loading: todayLoading } = useTodayActivity();

  const hiltonRings = useMemo(() => {
    const im = hiltonData ? tally(hiltonData.cases, reviewedIds) : null;
    const t = hiltonPriorityData ? tally(hiltonPriorityData.cases, reviewedIds) : null;
    // Projects ring is status-mode: active (ongoing) vs completed project
    // counts only — no overdue concept, and scheduled projects aren't part
    // of this composition (they show up in the Projects tab instead).
    const projectsRing = hiltonProjectsData
      ? { active: hiltonProjectsData.aggregate.ongoing, completed: hiltonProjectsData.aggregate.completed }
      : null;
    if (!im && !t && !projectsRing) return null;
    return {
      im: im || { active: 0, overdue: 0 },
      t: t || { active: 0, overdue: 0 },
      projects: projectsRing || { active: 0, completed: 0 },
    };
  }, [hiltonData, hiltonPriorityData, hiltonProjectsData, reviewedIds]);

  // Radisson has Installs (IM) and now T-priority wired up via
  // Chain_Code_Lookup__c — no Smartsheet projects/calendar exist yet.
  const radissonRings = useMemo(() => {
    const im = radissonData ? tally(radissonData.cases, reviewedIds) : null;
    const t = radissonPriorityData ? tally(radissonPriorityData.cases, reviewedIds) : null;
    if (!im && !t) return null;
    return { im: im || { active: 0, overdue: 0 }, t: t || { active: 0, overdue: 0 } };
  }, [radissonData, radissonPriorityData, reviewedIds]);

  const RINGS_BY_CLIENT = {
    hilton: { rings: hiltonRings, loading: hiltonLoading || hiltonPriorityLoading || hiltonProjectsLoading },
    radisson: { rings: radissonRings, loading: radissonLoading || radissonPriorityLoading },
  };

  // Any other live client (no T-priority yet, so the ring is Installs +
  // Projects only) — computed generically from useGenericClients' output
  // rather than one useMemo per client.
  CLIENTS.forEach((c) => {
    if (c.key === 'hilton' || c.key === 'radisson' || !c.live) return;
    const entry = genericByClient[c.key];
    const im = entry?.data ? tally(entry.data.cases, reviewedIds) : null;
    const projectsRing = entry?.projectsData
      ? { active: entry.projectsData.aggregate.ongoing, completed: entry.projectsData.aggregate.completed }
      : null;
    const rings = im || projectsRing ? { im: im || { active: 0, overdue: 0 }, t: { active: 0, overdue: 0 }, projects: projectsRing || { active: 0, completed: 0 } } : null;
    RINGS_BY_CLIENT[c.key] = { rings, loading: !!entry?.loading };
  });

  const todayCount = waves.length + rebuilds.length + projects.length;

  return (
    <div className="grid-wrap" style={{ padding: 0 }}>
      <div className="home-hero">
        <div className="home-hero-glow" aria-hidden="true" />
        <span className="home-hero-eyebrow">Enterprise Command Center</span>
        <h1 className="home-hero-title">Every client, one signal board.</h1>
        <p>
          One board per client. Each tile shows what's open right now — click through for the
          full case-by-case breakdown, team assignments, projects, and anything past its
          one-week SLA.
        </p>
      </div>

      {!todayLoading && todayCount > 0 && (
        <div className="today-panel">
          <div className="today-panel-head">
            <CalendarClock size={15} strokeWidth={2.2} />
            <span>Scheduled today</span>
            <span className="today-date">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'short', day: 'numeric' })}
            </span>
          </div>
          <div className="today-chips">
            {waves.map((w) => (
              <button
                key={`wave-${w.wave}-${w.region}`}
                type="button"
                className="today-chip wave"
                onClick={() => onOpenClient('hilton', 'calendar')}
              >
                <span className="today-chip-client">{w.client}</span>
                Wave {w.wave} · {w.region} · {w.propertyCount} propert{w.propertyCount === 1 ? 'y' : 'ies'}
              </button>
            ))}
            {rebuilds.map((r) => (
              <a
                key={`rebuild-${r.id}`}
                className="today-chip rebuild"
                href={r.caseUrl || undefined}
                target="_blank"
                rel="noreferrer"
              >
                <span className="today-chip-client">{r.client}</span>
                Rebuild · {r.propertyCode || r.id}
              </a>
            ))}
            {projects.map((p) => (
              <button
                key={`project-${p.sheetId}-${p.date}`}
                type="button"
                className="today-chip project"
                onClick={() => onOpenClient('hilton', 'projects')}
              >
                <span className="today-chip-client">{p.client}</span>
                {p.projectName} · {p.propertyCount} propert{p.propertyCount === 1 ? 'y' : 'ies'}
              </button>
            ))}
          </div>
        </div>
      )}

      {!todayLoading && todayCount === 0 && (
        <div className="today-panel is-quiet">
          <div className="today-panel-head">
            <CalendarClock size={15} strokeWidth={2.2} />
            <span>Nothing scheduled today</span>
          </div>
        </div>
      )}

      <div className="client-grid">
        {CLIENTS.map((client) => {
          const info = RINGS_BY_CLIENT[client.key];
          return (
            <ClientTile
              key={client.key}
              client={client}
              rings={info ? info.rings : null}
              loading={info ? info.loading : false}
              onOpen={onOpenClient}
            />
          );
        })}
      </div>
    </div>
  );
}
