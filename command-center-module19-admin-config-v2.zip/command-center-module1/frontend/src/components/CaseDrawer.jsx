import { useMemo, useState } from 'react';
import CaseRow from './CaseRow';
import { STATUS_META } from '../utils/format';
import { effectiveOverdue } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';

const STATUS_ORDER = ['active', 'pending_client', 'done', 'unknown'];

export default function CaseDrawer({ categoryKey, bucket, searchQuery, onClose }) {
  const { reviewedIds } = useOverdueOverrides();
  const [statusFilter, setStatusFilter] = useState(null); // null = all, 'overdue' is a virtual filter

  const overdueCount = useMemo(
    () => bucket.cases.filter((c) => effectiveOverdue(c, reviewedIds)).length,
    [bucket.cases, reviewedIds]
  );

  const cases = useMemo(() => {
    let list = bucket.cases;

    if (statusFilter === 'overdue') {
      list = list.filter((c) => effectiveOverdue(c, reviewedIds));
    } else if (statusFilter) {
      list = list.filter((c) => c.operationalStatus === statusFilter);
    }

    const q = searchQuery?.trim().toLowerCase();
    if (q) {
      list = list.filter((c) =>
        [c.id, c.propertyCode, c.subject, c.reason, c.accountName, c.ownerName]
          .filter(Boolean)
          .some((field) => field.toLowerCase().includes(q))
      );
    }

    return [...list].sort((a, b) => {
      const aOverdue = effectiveOverdue(a, reviewedIds);
      const bOverdue = effectiveOverdue(b, reviewedIds);
      if (aOverdue !== bOverdue) return aOverdue ? -1 : 1;
      const statusDiff =
        STATUS_ORDER.indexOf(a.operationalStatus) - STATUS_ORDER.indexOf(b.operationalStatus);
      if (statusDiff !== 0) return statusDiff;
      return new Date(b.lastModifiedDate || 0) - new Date(a.lastModifiedDate || 0);
    });
  }, [bucket.cases, statusFilter, searchQuery, reviewedIds]);

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <div className="drawer" role="dialog" aria-label={`${bucket.label} cases`}>
        <div className="drawer-header">
          <div>
            <h2>{bucket.label}</h2>
            <p>{bucket.description}</p>
          </div>
          <button type="button" className="drawer-close" onClick={onClose} aria-label="Close">
            ✕
          </button>
        </div>

        <div className="drawer-filters">
          {overdueCount > 0 && (
            <button
              type="button"
              className={`filter-chip overdue${statusFilter === 'overdue' ? ' on' : ''}`}
              onClick={() => setStatusFilter((cur) => (cur === 'overdue' ? null : 'overdue'))}
            >
              <span className="swatch" style={{ background: 'currentColor' }} />
              Overdue · {overdueCount}
            </button>
          )}
          {STATUS_ORDER.filter((s) => bucket.counts[s]).map((s) => (
            <button
              key={s}
              type="button"
              className={`filter-chip ${s}${statusFilter === s ? ' on' : ''}`}
              onClick={() => setStatusFilter((cur) => (cur === s ? null : s))}
            >
              <span className="swatch" style={{ background: 'currentColor' }} />
              {STATUS_META[s].label} · {bucket.counts[s]}
            </button>
          ))}
        </div>

        <div className="drawer-list">
          {cases.length === 0 ? (
            <div className="drawer-empty">No cases match this filter.</div>
          ) : (
            cases.map((c) => <CaseRow key={c.id} c={c} />)
          )}
        </div>
      </div>
    </>
  );
}
