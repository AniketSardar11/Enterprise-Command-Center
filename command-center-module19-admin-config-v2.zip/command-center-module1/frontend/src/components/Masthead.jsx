import { useTick } from '../hooks/useTick';
import { secondsAgoLabel } from '../utils/format';
import { Settings } from 'lucide-react';

function BrandMark() {
  return (
    <svg width="30" height="30" viewBox="0 0 30 30" className="brand-mark" aria-hidden="true">
      <rect width="30" height="30" rx="8" fill="url(#brand-mark-grad)" />
      <circle cx="15" cy="15" r="8.5" fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth="2" />
      <circle
        cx="15"
        cy="15"
        r="8.5"
        fill="none"
        stroke="#fff"
        strokeWidth="2"
        strokeLinecap="round"
        strokeDasharray="24 100"
        transform="rotate(-90 15 15)"
      />
      <defs>
        <linearGradient id="brand-mark-grad" x1="0" y1="0" x2="30" y2="30">
          <stop offset="0%" stopColor="var(--brand)" />
          <stop offset="100%" stopColor="var(--brand-dark)" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export default function Masthead({ title, clientTag, onBack, totals, lastFetchedAt, hasError, loading, onOpenAdmin }) {
  useTick(1000); // keep "synced Ns ago" live

  let statusClass = '';
  let statusLabel = 'connecting…';
  if (hasError) {
    statusClass = 'error';
    statusLabel = 'connection lost';
  } else if (loading && !lastFetchedAt) {
    statusClass = 'stale';
    statusLabel = 'connecting…';
  } else if (lastFetchedAt) {
    statusClass = '';
    statusLabel = secondsAgoLabel(lastFetchedAt);
  }

  return (
    <header className="masthead">
      <div className="masthead-id">
        {onBack && (
          <button type="button" className="back-btn" onClick={onBack}>
            ← All clients
          </button>
        )}
        <BrandMark />
        <h1>{title}</h1>
        {clientTag && <span className="client-tag mono">{clientTag}</span>}
      </div>

      <div className="masthead-status">
        <span className={`live-dot ${statusClass}`}>
          <span className="dot" />
          {statusLabel}
        </span>

        {totals && (
          <div className="masthead-totals">
            {totals.overdue > 0 && (
              <div className="totals-stat overdue">
                <span className="n">{totals.overdue}</span>
                <span className="l">Overdue</span>
              </div>
            )}
            <div className="totals-stat active">
              <span className="n">{totals.active}</span>
              <span className="l">Active</span>
            </div>
            <div className="totals-stat pending">
              <span className="n">{totals.pending_client}</span>
              <span className="l">Responded</span>
            </div>
            <div className="totals-stat done">
              <span className="n">{totals.done}</span>
              <span className="l">Done</span>
            </div>
          </div>
        )}

        {onOpenAdmin && (
          <button type="button" className="admin-trigger" onClick={onOpenAdmin} title="Admin — Board Config">
            <Settings size={16} strokeWidth={2.2} />
          </button>
        )}
      </div>
    </header>
  );
}
