import { useMemo } from 'react';
import { ChevronRight } from 'lucide-react';
import { effectiveOverdue } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';

function initialsOf(name) {
  if (!name) return '—';
  const parts = name.trim().split(/\s+/);
  return parts
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase())
    .join('');
}

export default function TeamPanel({ cases, searchQuery, onOpenOwner }) {
  const { reviewedIds } = useOverdueOverrides();

  const byOwner = useMemo(() => {
    const q = searchQuery?.trim().toLowerCase();
    const filtered = q
      ? cases.filter((c) =>
          [c.id, c.propertyCode, c.subject, c.reason, c.accountName, c.ownerName]
            .filter(Boolean)
            .some((field) => field.toLowerCase().includes(q))
        )
      : cases;

    const open = filtered.filter((c) => c.operationalStatus !== 'done');
    const map = new Map();

    open.forEach((c) => {
      const owner = c.ownerName || 'Unassigned';
      if (!map.has(owner)) {
        map.set(owner, { owner, active: 0, pending_client: 0, overdue: 0, cases: [] });
      }
      const entry = map.get(owner);
      entry.cases.push(c);
      if (c.operationalStatus === 'active') entry.active += 1;
      if (c.operationalStatus === 'pending_client') entry.pending_client += 1;
      if (effectiveOverdue(c, reviewedIds)) entry.overdue += 1;
    });

    return [...map.values()].sort((a, b) => {
      if (a.overdue !== b.overdue) return b.overdue - a.overdue;
      const totalA = a.active + a.pending_client;
      const totalB = b.active + b.pending_client;
      return totalB - totalA;
    });
  }, [cases, searchQuery, reviewedIds]);

  if (byOwner.length === 0) {
    return <div className="team-empty">No open tasks assigned right now.</div>;
  }

  return (
    <div className="team-grid">
      {byOwner.map((entry) => {
        const total = entry.active + entry.pending_client;
        const pct = (n) => (total > 0 ? (n / total) * 100 : 0);
        return (
          <button
            type="button"
            key={entry.owner}
            className={`team-card${entry.overdue > 0 ? ' has-overdue' : ''}`}
            onClick={() => onOpenOwner?.(entry.owner, entry.cases)}
          >
            <div className="team-card-head">
              <span className="team-avatar">{initialsOf(entry.owner)}</span>
              <span className="team-name">{entry.owner}</span>
              {entry.overdue > 0 && (
                <span className="team-overdue-badge">{entry.overdue} overdue</span>
              )}
            </div>

            <div className="team-stack">
              {entry.overdue > 0 && (
                <div className="seg overdue" style={{ width: `${pct(entry.overdue)}%` }} />
              )}
              {entry.active - entry.overdue > 0 && (
                <div className="seg active" style={{ width: `${pct(entry.active - entry.overdue)}%` }} />
              )}
              {entry.pending_client > 0 && (
                <div className="seg pending_client" style={{ width: `${pct(entry.pending_client)}%` }} />
              )}
            </div>

            <div className="team-counts">
              <span className="count-item active">
                <span className="swatch" />
                {entry.active} active
              </span>
              <span className="count-item pending">
                <span className="swatch" />
                {entry.pending_client} responded
              </span>
              <span className="count-item">{total} open tasks</span>
              <span className="team-card-cta">
                View tasks <ChevronRight size={13} strokeWidth={2.4} />
              </span>
            </div>
          </button>
        );
      })}
    </div>
  );
}
