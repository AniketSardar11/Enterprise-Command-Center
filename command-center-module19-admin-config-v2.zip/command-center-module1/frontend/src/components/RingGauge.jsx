/**
 * A ring gauge with two modes:
 *
 * 'attention' (default, used by IM/T case rings) — active cases split into
 * "on time" (amber) vs "overdue" (red). Deliberately excludes done/closed
 * and pending/responded volume — those can run into the thousands for a
 * mature client and would visually drown out the signal that matters here.
 *
 * 'status' (used by the Projects ring) — there's no "overdue" concept for
 * projects, and with a small, fixed project count (18, not thousands),
 * showing the active-vs-completed composition is actually useful rather
 * than noisy. Segments: completed (green) + active/ongoing (amber), out of
 * total projects. Scheduled projects aren't part of this composition (per
 * the home dashboard's ring spec: active + completed only) — they still
 * show up as a count elsewhere on the tile.
 */
export default function RingGauge({ active, overdue = 0, completed = 0, size = 76, mode = 'attention' }) {
  const radius = size / 2 - 6;
  const circumference = 2 * Math.PI * radius;
  const center = size / 2;

  const isStatus = mode === 'status';

  const total = isStatus ? active + completed : active;
  const segments = isStatus
    ? [
        { key: 'completed', value: completed, color: 'var(--green)' },
        { key: 'active', value: active, color: 'var(--amber)' },
      ].filter((s) => s.value > 0)
    : [
        { key: 'overdue', value: overdue, color: 'var(--red)' },
        { key: 'on_time', value: Math.max(active - overdue, 0), color: 'var(--amber)' },
      ].filter((s) => s.value > 0);

  let offsetAcc = 0;
  const gapDeg = segments.length > 1 ? 3 : 0;

  return (
    <div className="ring-gauge" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="var(--surface-sunken)"
          strokeWidth="7"
        />
        {total === 0 ? null : (
          <g transform={`rotate(-90 ${center} ${center})`}>
            {segments.map((seg) => {
              const frac = seg.value / total;
              const dash = Math.max(frac * circumference - gapDeg, 0);
              const dashArray = `${dash} ${circumference - dash}`;
              const dashOffset = -((offsetAcc / total) * circumference);
              offsetAcc += seg.value;
              return (
                <circle
                  key={seg.key}
                  cx={center}
                  cy={center}
                  r={radius}
                  fill="none"
                  stroke={seg.color}
                  strokeWidth="7"
                  strokeLinecap="round"
                  strokeDasharray={dashArray}
                  strokeDashoffset={dashOffset}
                />
              );
            })}
          </g>
        )}
      </svg>
      {isStatus ? (
        <div className="ring-gauge-center" style={{ fontSize: size < 70 ? '0.85em' : undefined }}>
          <span className="n mono">{total}</span>
          <span className="l">projects</span>
        </div>
      ) : (
        <>
          <div className="ring-gauge-center" style={{ fontSize: size < 70 ? '0.85em' : undefined }}>
            <span className="n mono">{active}</span>
            <span className="l">active</span>
          </div>
          {overdue > 0 && (
            <span className="ring-gauge-overdue" title={`${overdue} overdue`}>
              {overdue}
            </span>
          )}
        </>
      )}
    </div>
  );
}
