import { AlertTriangle, ArrowRight } from 'lucide-react';
import RingGauge from './RingGauge';

// IM and T are attention rings (active vs overdue). Projects is a status
// ring (active vs completed) — there's no overdue concept for projects.
const RING_DEFS = [
  { key: 'im', label: 'Installs', mode: 'attention' },
  { key: 't', label: 'T Priority', mode: 'attention' },
  { key: 'projects', label: 'Projects', mode: 'status' },
];

export default function ClientTile({ client, rings, loading, onOpen }) {
  const { name, initials, live, code, capabilities } = client;

  if (!live) {
    return (
      <div className="client-tile is-disabled" aria-disabled="true">
        <div className="tile-head" style={{ filter: 'grayscale(0.4)' }}>
          <span className="avatar">{initials}</span>
          <span className="name">{name}</span>
          <span className="tile-badge soon">Coming soon</span>
        </div>
        <div className="tile-body">
          {code && <span className="tile-code mono">{code}</span>}
          <p className="tile-footer soon-text">Not connected yet — SFDC integration pending.</p>
        </div>
      </div>
    );
  }

  // Only show rings this client actually has data for — a "0" T-priority
  // ring would misleadingly look like "zero cases" rather than "not wired
  // up yet". Defaults to showing all three if capabilities isn't set.
  const visibleRings = capabilities ? RING_DEFS.filter((r) => capabilities[r.key] !== false) : RING_DEFS;

  // Overdue only applies to IM/T case rings — projects have no overdue concept.
  const totalOverdue = (rings?.im?.overdue || 0) + (rings?.t?.overdue || 0);
  const overdueLabel = visibleRings
    .filter((r) => r.mode === 'attention')
    .map((r) => r.label)
    .join(' · ');

  return (
    <button type="button" className="client-tile is-live" onClick={() => onOpen(client.key)}>
      <div className="tile-head">
        <span className="avatar">{initials}</span>
        <span className="name">{name}</span>
        <span className="tile-badge live">Live</span>
      </div>
      <div className="tile-body">
        {loading && !rings ? (
          <p className="tile-footer">Loading case data…</p>
        ) : (
          <>
            <div className="tile-rings-row">
              {visibleRings.map((r) => {
                const ringData = rings?.[r.key];
                return (
                  <div className="tile-ring-col" key={r.key}>
                    <RingGauge
                      mode={r.mode}
                      active={ringData?.active || 0}
                      overdue={ringData?.overdue || 0}
                      completed={ringData?.completed || 0}
                      size={60}
                    />
                    <span className="tile-ring-label">{r.label}</span>
                  </div>
                );
              })}
            </div>

            {totalOverdue > 0 && (
              <span className="tile-overdue">
                <AlertTriangle size={13} strokeWidth={2.4} />
                {totalOverdue} overdue across {overdueLabel}
              </span>
            )}

            <p className="tile-footer">
              Open full board <ArrowRight size={13} strokeWidth={2.4} />
            </p>
          </>
        )}
      </div>
    </button>
  );
}
