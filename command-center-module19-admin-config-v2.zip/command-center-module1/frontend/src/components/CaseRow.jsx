import { CheckCircle2, RotateCcw } from 'lucide-react';
import StatusPill from './StatusPill';
import { relativeTime } from '../utils/format';
import { isOverdue, effectiveOverdue, daysOpen } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';

export default function CaseRow({ c }) {
  const { reviewedIds, markReviewed, unmarkReviewed } = useOverdueOverrides();
  const rawOverdue = isOverdue(c); // date-based, ignoring overrides
  const overdue = effectiveOverdue(c, reviewedIds); // what's actually shown
  const isReviewed = rawOverdue && !overdue;

  const RowTag = c.caseUrl ? 'a' : 'div';
  const rowProps = c.caseUrl
    ? { href: c.caseUrl, target: '_blank', rel: 'noreferrer' }
    : {};

  return (
    <RowTag className={`case-row${overdue ? ' is-overdue' : ''}${isReviewed ? ' is-reviewed' : ''}`} {...rowProps}>
      <span className="case-id mono">{c.id}</span>
      <span className={`prop-code mono${c.propertyCodeInferred ? ' inferred' : ''}`}>
        {c.propertyCode || '—'}
      </span>
      <span className="subject">
        {c.subject || c.reason || 'Untitled case'}
        {c.subject && c.reason && <span className="reason">{c.reason}</span>}
      </span>
      <span className="owner">{c.ownerName || '—'}</span>
      <StatusPill status={c.operationalStatus} overdue={overdue} />
      <span className={`age mono${overdue ? ' is-overdue' : ''}`}>
        {rawOverdue ? `${daysOpen(c)}d` : relativeTime(c.lastModifiedDate)}
      </span>

      {rawOverdue && (
        <button
          type="button"
          className={`review-btn${isReviewed ? ' is-reviewed' : ''}`}
          title={isReviewed ? 'Mark overdue again' : 'Mark reviewed — stop flagging this as overdue'}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (isReviewed) unmarkReviewed(c.id);
            else markReviewed(c.id);
          }}
        >
          {isReviewed ? <RotateCcw size={12} strokeWidth={2.4} /> : <CheckCircle2 size={12} strokeWidth={2.4} />}
          {isReviewed ? 'Reviewed' : 'Mark reviewed'}
        </button>
      )}
    </RowTag>
  );
}
