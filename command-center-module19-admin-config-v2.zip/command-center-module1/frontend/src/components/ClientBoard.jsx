import { useMemo, useState } from 'react';
import { LayoutGrid, Users, ArrowUpDown, CalendarRange, FolderKanban } from 'lucide-react';
import Masthead from './Masthead';
import CategoryGrid from './CategoryGrid';
import CaseDrawer from './CaseDrawer';
import TeamPanel from './TeamPanel';
import SegmentedTabs from './SegmentedTabs';
import WaveCalendar from './WaveCalendar';
import ProjectsPanel from './ProjectsPanel';
import { tally } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';

const SORT_OPTIONS = [
  { key: 'attention', label: 'Needs attention' },
  { key: 'volume', label: 'Volume' },
  { key: 'alpha', label: 'A–Z' },
];

const ALL_BOARD_TABS = [
  { key: 'cases', label: 'Cases', icon: <LayoutGrid size={14} strokeWidth={2.2} /> },
  { key: 'team', label: 'Team & tasks', icon: <Users size={14} strokeWidth={2.2} /> },
  { key: 'calendar', label: 'Calendar', icon: <CalendarRange size={14} strokeWidth={2.2} /> },
  { key: 'projects', label: 'Projects', icon: <FolderKanban size={14} strokeWidth={2.2} /> },
];

// IM = installation/configuration cases (12-category Reason-based taxonomy).
// T = priority-scale cases (T0/T1/T2/TS/TT0/TT1/TT2) — a completely different
// team/queue, confirmed by non-overlapping owner rosters and unrelated Reasons.
const DATA_SOURCE_TABS = [
  { key: 'im', label: 'Installs' },
  { key: 't', label: 'T (Priority)' },
];

// Defaults if a client config doesn't specify capabilities at all — keeps
// older/simpler client entries working without every one needing this field.
const DEFAULT_CAPABILITIES = { im: true, t: false, calendar: false, projects: false };

export default function ClientBoard({
  client,
  data,
  error,
  loading,
  lastFetchedAt,
  refresh,
  priorityData,
  priorityError,
  priorityLoading,
  priorityRefresh,
  projectsData,
  projectsError,
  projectsLoading,
  projectsRefresh,
  initialTab,
  onBack,
}) {
  const capabilities = client.capabilities || DEFAULT_CAPABILITIES;
  const boardTabs = ALL_BOARD_TABS.filter((t) => capabilities[t.key] !== false);

  const { reviewedIds } = useOverdueOverrides();
  const [openKey, setOpenKey] = useState(null);
  const [openOwner, setOpenOwner] = useState(null); // { owner, cases } for the Team & Tasks drill-in
  const [sortMode, setSortMode] = useState('attention');
  const [query, setQuery] = useState('');
  // Fall back to 'cases' if the requested initial tab isn't available for this client.
  const [tab, setTab] = useState(boardTabs.some((t) => t.key === initialTab) ? initialTab : 'cases');
  const [dataSource, setDataSource] = useState('im'); // 'im' | 't' — 't' only reachable when capabilities.t is true

  const switchDataSource = (key) => {
    setDataSource(key);
    setOpenKey(null); // avoid a stale drawer referencing a category that doesn't exist in the other dataset
    setOpenOwner(null);
    setQuery('');
  };

  const isIM = dataSource === 'im' || !capabilities.t;
  const activeData = isIM ? data : priorityData;
  const activeError = isIM ? error : priorityError;
  const activeLoading = isIM ? loading : priorityLoading;
  const activeRefresh = isIM ? refresh : priorityRefresh;
  const categoryMap = activeData ? (isIM ? activeData.byCategory : activeData.byPriority) : null;

  // Masthead totals follow whichever dataset is on screen — except on the
  // Calendar tab, which isn't case data at all, so it falls back to IM as a
  // stable baseline rather than flickering based on whatever was last selected.
  const totalsSourceCases = tab === 'calendar' || tab === 'projects' ? data?.cases : activeData?.cases;
  const totals = useMemo(() => {
    if (!totalsSourceCases) return null;
    return tally(totalsSourceCases, reviewedIds);
  }, [totalsSourceCases, reviewedIds]);

  const filteredCategoryMap = useMemo(() => {
    if (!categoryMap) return {};
    const q = query.trim().toLowerCase();
    if (!q) return categoryMap;

    const result = {};
    Object.entries(categoryMap).forEach(([key, bucket]) => {
      const matches = bucket.cases.filter((c) =>
        [c.id, c.propertyCode, c.subject, c.reason, c.accountName, c.ownerName]
          .filter(Boolean)
          .some((field) => field.toLowerCase().includes(q))
      );
      if (matches.length > 0) {
        const counts = { active: 0, pending_client: 0, done: 0, unknown: 0 };
        matches.forEach((c) => {
          counts[c.operationalStatus] = (counts[c.operationalStatus] || 0) + 1;
        });
        result[key] = { ...bucket, cases: matches, counts };
      }
    });
    return result;
  }, [categoryMap, query]);

  const openBucket = openKey ? categoryMap?.[openKey] : null;

  return (
    <div className="app">
      <Masthead
        title="Enterprise Command Center"
        clientTag={client.key.toUpperCase()}
        onBack={onBack}
        totals={totals}
        lastFetchedAt={lastFetchedAt}
        hasError={!!error}
        loading={loading}
      />

      {!activeLoading && !activeError && activeData && tab !== 'calendar' && tab !== 'projects' && (
        <div className="toolbar">
          <input
            className="search-input"
            type="text"
            placeholder="Search case #, property code, subject, owner…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />

          <SegmentedTabs tabs={boardTabs} activeKey={tab} onChange={setTab} />

          {capabilities.t && (
            <SegmentedTabs
              tabs={DATA_SOURCE_TABS}
              activeKey={dataSource}
              onChange={switchDataSource}
              size="sm"
            />
          )}

          {tab === 'cases' && (
            <div className="sort-group">
              <ArrowUpDown size={12} className="sort-group-icon" strokeWidth={2.2} />
              {SORT_OPTIONS.map((opt) => (
                <button
                  key={opt.key}
                  type="button"
                  className={`sort-btn${sortMode === opt.key ? ' on' : ''}`}
                  onClick={() => setSortMode(opt.key)}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {(tab === 'calendar' || tab === 'projects') && (
        <div className="toolbar">
          <SegmentedTabs tabs={boardTabs} activeKey={tab} onChange={setTab} />
        </div>
      )}

      {tab === 'cases' && (
        <div className="grid-wrap">
          {activeLoading && !activeData && (
            <div className="state-screen">
              <div className="scan-line" />
              <p>Pulling live case data from SFDC…</p>
            </div>
          )}

          {activeError && !activeData && (
            <div className="state-screen">
              <p>Couldn't reach the case feed.</p>
              <span className="mono-detail">{activeError.message}</span>
              <button type="button" className="retry-btn" onClick={activeRefresh}>
                Retry
              </button>
            </div>
          )}

          {activeData && (
            <CategoryGrid
              byCategory={filteredCategoryMap}
              sortMode={sortMode}
              openKey={openKey}
              onSelect={setOpenKey}
            />
          )}
        </div>
      )}

      {tab === 'team' && (
        <div className="team-wrap">
          {activeData && (
            <TeamPanel
              cases={activeData.cases}
              searchQuery={query}
              onOpenOwner={(owner, ownerCases) => setOpenOwner({ owner, cases: ownerCases })}
            />
          )}
        </div>
      )}

      {tab === 'calendar' && <WaveCalendar />}

      {tab === 'projects' && (
        <ProjectsPanel
          data={projectsData}
          error={projectsError}
          loading={projectsLoading}
          refresh={projectsRefresh}
        />
      )}

      {openBucket && (
        <CaseDrawer
          categoryKey={openKey}
          bucket={openBucket}
          searchQuery={query}
          onClose={() => setOpenKey(null)}
        />
      )}

      {openOwner && (
        <CaseDrawer
          categoryKey={`owner:${openOwner.owner}`}
          bucket={{
            label: openOwner.owner,
            description: `${openOwner.cases.length} open task${openOwner.cases.length === 1 ? '' : 's'} assigned to ${openOwner.owner} (${isIM ? 'Installs' : 'T priority'})`,
            cases: openOwner.cases,
            counts: tally(openOwner.cases, reviewedIds),
          }}
          searchQuery=""
          onClose={() => setOpenOwner(null)}
        />
      )}
    </div>
  );
}
