import CategoryCard from './CategoryCard';
import { effectiveOverdue } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';

function totalOf(bucket) {
  const c = bucket.counts;
  return (c.active || 0) + (c.pending_client || 0) + (c.done || 0) + (c.unknown || 0);
}

function overdueOf(bucket, reviewedIds) {
  return bucket.cases.filter((c) => effectiveOverdue(c, reviewedIds)).length;
}

export function sortEntries(byCategory, sortMode, reviewedIds) {
  const entries = Object.entries(byCategory).filter(([, bucket]) => totalOf(bucket) > 0);

  if (sortMode === 'alpha') {
    entries.sort((a, b) => a[1].label.localeCompare(b[1].label));
  } else if (sortMode === 'volume') {
    entries.sort((a, b) => totalOf(b[1]) - totalOf(a[1]));
  } else {
    // default: 'attention' — overdue first, then active-needing-eyes, then volume
    entries.sort((a, b) => {
      const overdueDiff = overdueOf(b[1], reviewedIds) - overdueOf(a[1], reviewedIds);
      if (overdueDiff !== 0) return overdueDiff;
      const activeDiff = (b[1].counts.active || 0) - (a[1].counts.active || 0);
      if (activeDiff !== 0) return activeDiff;
      return totalOf(b[1]) - totalOf(a[1]);
    });
  }
  return entries;
}

export default function CategoryGrid({ byCategory, sortMode, openKey, onSelect }) {
  const { reviewedIds } = useOverdueOverrides();
  const entries = sortEntries(byCategory, sortMode, reviewedIds);

  if (entries.length === 0) {
    return <div className="drawer-empty">No open cases match this view.</div>;
  }

  return (
    <div className="category-grid">
      {entries.map(([key, bucket]) => (
        <CategoryCard
          key={key}
          categoryKey={key}
          bucket={bucket}
          isOpen={openKey === key}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
}
