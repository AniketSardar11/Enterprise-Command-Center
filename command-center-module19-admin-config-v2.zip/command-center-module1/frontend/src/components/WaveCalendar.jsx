import { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, CalendarDays, Download, AlertCircle } from 'lucide-react';
import { useWeekCalendar } from '../hooks/useWeekCalendar';
import { formatWeekRange, formatDayHeader } from '../utils/week';

// A small fixed palette keyed by region, so the same region always reads the
// same color across the whole calendar (rather than one color per wave,
// which would shift constantly as waves roll forward week to week).
const REGION_COLORS = {
  AMER: { bg: 'var(--brand-tint)', border: 'var(--brand)', text: 'var(--brand-dark)' },
  EMEA: { bg: 'var(--blue-tint)', border: 'var(--blue)', text: 'var(--blue)' },
  APAC: { bg: 'var(--amber-tint)', border: 'var(--amber)', text: 'var(--amber-strong)' },
};
const FALLBACK_COLOR = { bg: 'var(--grey-tint)', border: 'var(--grey)', text: 'var(--text-secondary)' };

function colorFor(region) {
  return REGION_COLORS[region] || FALLBACK_COLOR;
}

export default function WaveCalendar() {
  const {
    weekStart,
    weekDates,
    cellsByDate,
    rebuildByDate,
    projectCellsByDate,
    unscheduledRebuildCount,
    loading,
    error,
    goToToday,
    goPrevWeek,
    goNextWeek,
    refresh,
  } = useWeekCalendar();

  const captureRef = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    if (!captureRef.current) return;
    setDownloading(true);
    try {
      const html2canvas = (await import('html2canvas')).default;
      const canvas = await html2canvas(captureRef.current, {
        backgroundColor: getComputedStyle(document.body).getPropertyValue('--surface') || '#ffffff',
        scale: 2,
      });
      const link = document.createElement('a');
      link.download = `hilton-rollout-week-of-${weekDates[0]}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error('Calendar export failed', err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="calendar-wrap">
      <div className="calendar-toolbar">
        <div className="calendar-nav">
          <button type="button" className="nav-icon-btn" onClick={goPrevWeek} aria-label="Previous week">
            <ChevronLeft size={16} strokeWidth={2.4} />
          </button>
          <div className="calendar-range">
            <CalendarDays size={14} strokeWidth={2.2} />
            {formatWeekRange(weekStart)}
          </div>
          <button type="button" className="nav-icon-btn" onClick={goNextWeek} aria-label="Next week">
            <ChevronRight size={16} strokeWidth={2.4} />
          </button>
          <button type="button" className="today-btn" onClick={goToToday}>
            Today
          </button>
        </div>

        <button type="button" className="download-btn" onClick={handleDownload} disabled={downloading || loading}>
          <Download size={14} strokeWidth={2.3} />
          {downloading ? 'Exporting…' : 'Download as image'}
        </button>
      </div>

      {error && (
        <div className="state-screen">
          <p>Couldn't load the rollout calendar.</p>
          <span className="mono-detail">{error.message}</span>
          <button type="button" className="retry-btn" onClick={refresh}>
            Retry
          </button>
        </div>
      )}

      {!error && (
        <div className="calendar-capture" ref={captureRef}>
          <div className="calendar-capture-head">
            <span className="calendar-capture-title">Hilton Rollout — {formatWeekRange(weekStart)}</span>
          </div>

          <div className="calendar-grid">
            {weekDates.map((dateStr) => {
              const date = new Date(`${dateStr}T00:00:00`);
              const { weekday, dayNum } = formatDayHeader(date);
              const cells = cellsByDate.get(dateStr) || [];
              const projectCells = projectCellsByDate.get(dateStr) || [];
              const isEmpty = cells.length === 0 && projectCells.length === 0;
              return (
                <div key={dateStr} className="calendar-col">
                  <div className="calendar-day-head">
                    <span className="weekday">{weekday}</span>
                    <span className="daynum mono">{dayNum}</span>
                  </div>
                  <div className="calendar-day-body">
                    {loading && isEmpty && <div className="calendar-skeleton" />}
                    {!loading && isEmpty && <div className="calendar-empty-day">—</div>}
                    {cells.map((c) => {
                      const color = colorFor(c.region);
                      return (
                        <div
                          key={`${c.wave}-${c.region}`}
                          className="wave-cell"
                          style={{
                            background: color.bg,
                            borderLeftColor: color.border,
                            color: color.text,
                          }}
                        >
                          <div className="cal-cell-top">
                            {c.sheetUrl ? (
                              <a
                                className="wave-title project-cell-link"
                                href={c.sheetUrl}
                                target="_blank"
                                rel="noreferrer"
                              >
                                Wave {c.wave}
                              </a>
                            ) : (
                              <span className="wave-title">Wave {c.wave}</span>
                            )}
                            <span className="cal-cell-total mono" title="Total scheduled this day">
                              {c.propertyCount}
                            </span>
                          </div>
                          <span className="wave-meta mono">{c.region}</span>
                          <span className={`cal-cell-completed mono${c.completedCount > 0 ? ' is-done' : ''}`}>
                            ✓ {c.completedCount} completed
                          </span>
                        </div>
                      );
                    })}
                    {projectCells.map((c) => (
                      <div key={`${c.sheetId}-${c.date}`} className="project-cell" title={c.projectName}>
                        <div className="cal-cell-top">
                          {c.sheetUrl ? (
                            <a
                              className="wave-title project-cell-link"
                              href={c.sheetUrl}
                              target="_blank"
                              rel="noreferrer"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {c.projectName}
                            </a>
                          ) : (
                            <span className="wave-title">{c.projectName}</span>
                          )}
                          <span className="cal-cell-total mono" title="Total scheduled this day">
                            {c.propertyCount}
                          </span>
                        </div>
                        <span className={`cal-cell-completed mono${c.completedCount > 0 ? ' is-done' : ''}`}>
                          ✓ {c.completedCount} completed
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="rebuild-section">
            <div className="rebuild-label">Rebuild</div>
            <div className="rebuild-grid">
              {weekDates.map((dateStr) => {
                const items = rebuildByDate.get(dateStr) || [];
                return (
                  <div key={dateStr} className="rebuild-col">
                    {items.map((item) => (
                      <a
                        key={item.id}
                        className="rebuild-chip"
                        href={item.caseUrl || undefined}
                        target="_blank"
                        rel="noreferrer"
                        title={item.accountName || item.propertyCode}
                      >
                        {item.propertyCode || item.id}
                      </a>
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {unscheduledRebuildCount > 0 && (
        <div className="calendar-footnote">
          <AlertCircle size={13} strokeWidth={2.2} />
          {unscheduledRebuildCount} rebuild case{unscheduledRebuildCount === 1 ? '' : 's'} couldn't be dated from its
          description — not shown above.
        </div>
      )}
    </div>
  );
}
