export default function SegmentedTabs({ tabs, activeKey, onChange, size }) {
  const activeIndex = Math.max(
    0,
    tabs.findIndex((t) => t.key === activeKey)
  );

  return (
    <div
      className={`pill-switch${size === 'sm' ? ' pill-switch-sm' : ''}`}
      style={{ '--tab-count': tabs.length }}
    >
      <span
        className="pill-switch-thumb"
        style={{ transform: `translateX(${activeIndex * 100}%)` }}
      />
      {tabs.map((tab) => (
        <button
          key={tab.key}
          type="button"
          className={`pill-btn${tab.key === activeKey ? ' on' : ''}`}
          onClick={() => onChange(tab.key)}
        >
          {tab.icon}
          {tab.label}
        </button>
      ))}
    </div>
  );
}
