/**
 * The category card's signature element: a vertical bar whose fill height
 * reflects what fraction of the category's open cases are active (needing
 * eyes) vs. quiet (pending/done). It turns red instead of amber the moment
 * any of those active cases has breached its one-week SLA — the fill tells
 * you volume, the color tells you urgency.
 */
export default function SignalBar({ active, total, hasOverdue }) {
  const fraction = total > 0 ? active / total : 0;
  const heightPct = Math.max(fraction * 100, active > 0 ? 6 : 0);
  const allQuiet = active === 0;

  return (
    <div
      className={`signal-bar${allQuiet ? ' all-quiet' : ''}${hasOverdue ? ' has-overdue' : ''}`}
      role="img"
      aria-label={`${active} of ${total} cases active${hasOverdue ? ', overdue' : ''}`}
      title={`${active} of ${total} active${hasOverdue ? ' — SLA breached' : ''}`}
    >
      <div className="fill" style={{ height: `${heightPct}%` }} />
    </div>
  );
}
