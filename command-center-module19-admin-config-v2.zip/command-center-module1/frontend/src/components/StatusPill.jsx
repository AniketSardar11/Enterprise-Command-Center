import { STATUS_META } from '../utils/format';

export default function StatusPill({ status, overdue }) {
  const key = overdue ? 'overdue' : status;
  const meta = STATUS_META[key] || STATUS_META[status] || STATUS_META.unknown;
  return (
    <span className={`status-pill ${key}`}>
      <span className="swatch" />
      {meta.label}
    </span>
  );
}
