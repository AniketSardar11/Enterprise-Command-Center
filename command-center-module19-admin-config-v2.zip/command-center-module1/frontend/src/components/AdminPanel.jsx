import { useEffect, useState } from 'react';
import { Settings, X, Plus, Trash2, Loader2 } from 'lucide-react';
import { CLIENTS } from '../data/clients';
import {
  fetchAdminConfig,
  addCaseCategory,
  deleteCaseCategory,
  addSmartsheetSheet,
  deleteSmartsheetSheet,
} from '../api/client';

// Only clients with a live backend (Hilton/Radisson's dedicated services, or
// any other client wired through the generic /api/clients/:clientKey path)
// actually read this config back out — offering a "coming soon" client here
// would silently save an entry nothing ever consumes. If a client you need
// isn't in this list, it needs its SFDC identifiers confirmed and added to
// backend/config/clientIdentifiers.js first (and flipped to `live: true` in
// data/clients.js) — that's a one-time code change, not something this form
// can do on its own.
const CONNECTED_CLIENTS = CLIENTS.filter((c) => c.live);

const ADMIN_EMAIL_STORAGE_KEY = 'cc_admin_email';

const FIELD_OPTIONS = [
  { value: 'Reason', label: 'Reason (Hilton-style taxonomy)' },
  { value: 'Subject', label: 'Subject (Radisson-style taxonomy)' },
];

function emptyCategoryForm() {
  return { clientKey: CONNECTED_CLIENTS[0].key, field: 'Reason', label: '', matchType: 'contains', matchValue: '', sfdcReportUrl: '' };
}

function emptySheetForm() {
  return { clientKey: CONNECTED_CLIENTS[0].key, name: '', sheetIdOrUrl: '' };
}

/** Gate screen: capture the admin's email. The backend allowlist is the real check — this just collects it. */
function EmailGate({ onSubmit, error }) {
  const [email, setEmail] = useState('');

  return (
    <div className="admin-gate">
      <p>Enter your admin email to manage case categories and Smartsheet sheets.</p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (email.trim()) onSubmit(email.trim());
        }}
      >
        <input
          type="email"
          placeholder="you@ideas.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          autoFocus
        />
        <button type="submit">Continue</button>
      </form>
      {error && <div className="admin-error">{error}</div>}
    </div>
  );
}

function CategoryForm({ adminEmail, onAdded }) {
  const [form, setForm] = useState(emptyCategoryForm());
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const client = CONNECTED_CLIENTS.find((c) => c.key === form.clientKey);
      const record = await addCaseCategory(adminEmail, { ...form, clientCode: client?.code });
      onAdded(record);
      setForm(emptyCategoryForm());
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form className="admin-form" onSubmit={submit}>
      <div className="admin-form-row">
        <label>
          Client
          <select value={form.clientKey} onChange={set('clientKey')}>
            {CONNECTED_CLIENTS.map((c) => (
              <option key={c.key} value={c.key}>{c.name}</option>
            ))}
          </select>
        </label>
        <label>
          Match against
          <select value={form.field} onChange={set('field')}>
            {FIELD_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </label>
      </div>

      <label>
        Category label
        <input type="text" placeholder="e.g. Rate Migration" value={form.label} onChange={set('label')} required />
      </label>

      <div className="admin-form-row">
        <label>
          Match type
          <select value={form.matchType} onChange={set('matchType')}>
            <option value="contains">Contains (substring)</option>
            <option value="exact">Exact match</option>
          </select>
        </label>
        <label>
          Text to match
          <input
            type="text"
            placeholder="e.g. Rate Migration"
            value={form.matchValue}
            onChange={set('matchValue')}
            required
          />
        </label>
      </div>

      <label>
        SFDC report link <span className="optional">(optional, for reference)</span>
        <input
          type="url"
          placeholder="https://ideas-sas.lightning.force.com/lightning/r/Report/..."
          value={form.sfdcReportUrl}
          onChange={set('sfdcReportUrl')}
        />
      </label>

      {error && <div className="admin-error">{error}</div>}

      <button type="submit" className="admin-submit" disabled={submitting}>
        {submitting ? <Loader2 size={14} className="spin" /> : <Plus size={14} />}
        Add case category
      </button>
    </form>
  );
}

function SheetForm({ adminEmail, onAdded }) {
  const [form, setForm] = useState(emptySheetForm());
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const client = CONNECTED_CLIENTS.find((c) => c.key === form.clientKey);
      const record = await addSmartsheetSheet(adminEmail, { ...form, clientCode: client?.code });
      onAdded(record);
      setForm(emptySheetForm());
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form className="admin-form" onSubmit={submit}>
      <label>
        Client
        <select value={form.clientKey} onChange={set('clientKey')}>
          {CONNECTED_CLIENTS.map((c) => (
            <option key={c.key} value={c.key}>{c.name}</option>
          ))}
        </select>
      </label>

      <label>
        Project name
        <input
          type="text"
          placeholder="e.g. Hilton-530 | Winter Rate Refresh"
          value={form.name}
          onChange={set('name')}
          required
        />
      </label>

      <label>
        Smartsheet link or sheet ID
        <input
          type="text"
          placeholder="paste the Smartsheet URL or the numeric sheet ID"
          value={form.sheetIdOrUrl}
          onChange={set('sheetIdOrUrl')}
          required
        />
      </label>

      {error && <div className="admin-error">{error}</div>}

      <button type="submit" className="admin-submit" disabled={submitting}>
        {submitting ? <Loader2 size={14} className="spin" /> : <Plus size={14} />}
        Add Smartsheet project
      </button>
    </form>
  );
}

function clientName(key) {
  return CLIENTS.find((c) => c.key === key)?.name || key;
}

export default function AdminPanel({ onClose }) {
  const [adminEmail, setAdminEmail] = useState(() => localStorage.getItem(ADMIN_EMAIL_STORAGE_KEY) || '');
  const [gateError, setGateError] = useState(null);
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState(null);

  const loadConfig = (email) => {
    setLoading(true);
    setLoadError(null);
    fetchAdminConfig(email)
      .then((data) => {
        setConfig(data);
        localStorage.setItem(ADMIN_EMAIL_STORAGE_KEY, email);
        setAdminEmail(email);
        setGateError(null);
      })
      .catch((err) => {
        if (err.status === 401 || err.status === 403) {
          setGateError(err.message);
          setAdminEmail('');
          localStorage.removeItem(ADMIN_EMAIL_STORAGE_KEY);
        } else {
          setLoadError(err.message);
        }
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (adminEmail) loadConfig(adminEmail);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const removeCategory = async (record) => {
    if (!window.confirm(`Remove "${record.label}" from ${clientName(record.clientKey)}?`)) return;
    await deleteCaseCategory(adminEmail, record.id, record.clientKey);
    loadConfig(adminEmail);
  };

  const removeSheet = async (record) => {
    if (!window.confirm(`Remove "${record.name}" from ${clientName(record.clientKey)}?`)) return;
    await deleteSmartsheetSheet(adminEmail, record.id, record.clientKey);
    loadConfig(adminEmail);
  };

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <div className="drawer admin-drawer" role="dialog" aria-label="Admin config">
        <div className="drawer-header">
          <div>
            <h2><Settings size={16} strokeWidth={2.2} /> Admin — Board Config</h2>
            <p>
              Add a case reason/category or a Smartsheet project for a client — takes effect on the next
              board load, no code change needed.
            </p>
            <p className="admin-scope-note">
              Only connected clients ({CONNECTED_CLIENTS.map((c) => c.name).join(', ')}) are listed below —
              a brand-new client needs its SFDC identifiers confirmed first.
            </p>
          </div>
          <button type="button" className="drawer-close" onClick={onClose} aria-label="Close">
            <X size={16} />
          </button>
        </div>

        <div className="admin-body">
          {!adminEmail && <EmailGate onSubmit={loadConfig} error={gateError} />}

          {adminEmail && loading && !config && <div className="admin-loading">Loading…</div>}

          {adminEmail && loadError && <div className="admin-error">{loadError}</div>}

          {adminEmail && config && (
            <>
              <section className="admin-section">
                <h3>Case reasons / categories</h3>
                <CategoryForm adminEmail={adminEmail} onAdded={() => loadConfig(adminEmail)} />
                {config.caseCategories.length > 0 ? (
                  <ul className="admin-list">
                    {config.caseCategories.map((c) => (
                      <li key={c.id} className="admin-list-item">
                        <div>
                          <strong>{c.label}</strong>
                          <span className="admin-list-meta">
                            {clientName(c.clientKey)} · {c.field} {c.matchType === 'exact' ? '=' : 'contains'} “{c.matchValue}”
                          </span>
                          {c.sfdcReportUrl && (
                            <a href={c.sfdcReportUrl} target="_blank" rel="noreferrer" className="admin-list-link">
                              SFDC report ↗
                            </a>
                          )}
                        </div>
                        <button type="button" onClick={() => removeCategory(c)} aria-label="Remove">
                          <Trash2 size={14} />
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="admin-empty">No admin-added categories yet.</div>
                )}
              </section>

              <section className="admin-section">
                <h3>Smartsheet projects</h3>
                <SheetForm adminEmail={adminEmail} onAdded={() => loadConfig(adminEmail)} />
                {config.smartsheetSheets.length > 0 ? (
                  <ul className="admin-list">
                    {config.smartsheetSheets.map((s) => (
                      <li key={s.id} className="admin-list-item">
                        <div>
                          <strong>{s.name}</strong>
                          <span className="admin-list-meta">
                            {clientName(s.clientKey)} · sheet {s.sheetId}
                          </span>
                        </div>
                        <button type="button" onClick={() => removeSheet(s)} aria-label="Remove">
                          <Trash2 size={14} />
                        </button>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="admin-empty">No admin-added Smartsheet projects yet.</div>
                )}
              </section>
            </>
          )}
        </div>
      </div>
    </>
  );
}
