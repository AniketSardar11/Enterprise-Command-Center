import { AlertTriangle, Clock, CalendarClock, CheckCircle2, ExternalLink } from 'lucide-react';

// Projects have exactly three states — there's no "overdue" concept at the
// project level (see services/hiltonProjects.js for why). Ongoing first
// (needs the most attention), then Scheduled (starting soon), then
// Completed (reference only).
const SECTIONS = [
  { key: 'ongoing', label: 'Ongoing', icon: Clock, emptyText: 'Nothing currently in progress.' },
  { key: 'scheduled', label: 'Scheduled', icon: CalendarClock, emptyText: 'Nothing scheduled to start.' },
  { key: 'completed', label: 'Completed', icon: CheckCircle2, emptyText: 'No completed projects yet.' },
];

function formatStartsFrom(iso) {
  if (!iso) return null;
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function sortWithinSection(projects) {
  return [...projects].sort((a, b) => {
    if (a.error && !b.error) return 1;
    if (!a.error && b.error) return -1;
    // Scheduled: soonest start first.
    if (a.startsFrom && b.startsFrom && a.startsFrom !== b.startsFrom) {
      return a.startsFrom.localeCompare(b.startsFrom);
    }
    if (b.active !== a.active) return b.active - a.active;
    return a.name.localeCompare(b.name);
  });
}

export default function ProjectsPanel({ data, error, loading, refresh }) {
  if (loading && !data) {
    return (
      <div className="state-screen">
        <div className="scan-line" />
        <p>Pulling project status from Smartsheet…</p>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="state-screen">
        <p>Couldn't reach the project feed.</p>
        <span className="mono-detail">{error.message}</span>
        <button type="button" className="retry-btn" onClick={refresh}>
          Retry
        </button>
      </div>
    );
  }

  if (!data) return null;

  const { aggregate } = data;
  const bySection = {
    ongoing: sortWithinSection(data.projects.filter((p) => p.status === 'ongoing')),
    scheduled: sortWithinSection(data.projects.filter((p) => p.status === 'scheduled')),
    completed: sortWithinSection(data.projects.filter((p) => p.status === 'completed')),
  };

  return (
    <div className="projects-wrap">
      <div className="projects-summary">
        <div className="projects-summary-stat">
          <span className="n mono">{data.totalProjects}</span>
          <span className="l">Projects tracked</span>
        </div>
        <div className="projects-summary-stat">
          <span className="n mono amber">{aggregate.ongoing}</span>
          <span className="l">Ongoing</span>
        </div>
        <div className="projects-summary-stat">
          <span className="n mono blue">{aggregate.scheduled}</span>
          <span className="l">Scheduled</span>
        </div>
        <div className="projects-summary-stat">
          <span className="n mono green">{aggregate.completed}</span>
          <span className="l">Completed</span>
        </div>
      </div>

      {SECTIONS.map((section) => {
        const projects = bySection[section.key];
        const Icon = section.icon;
        return (
          <div key={section.key} className="project-section">
            <div className="project-section-head">
              <Icon size={14} strokeWidth={2.2} />
              <span>{section.label}</span>
              <span className="project-section-count mono">{projects.length}</span>
            </div>

            {projects.length === 0 ? (
              <p className="project-section-empty">{section.emptyText}</p>
            ) : (
              <div className="project-list">
                {projects.map((p) => (
                  <div key={p.sheetId || p.name} className={`project-card status-${p.status}`}>
                    <div className="project-card-top">
                      {p.sheetUrl ? (
                        <a
                          className="project-name project-name-link"
                          href={p.sheetUrl}
                          target="_blank"
                          rel="noreferrer"
                          title="Open this sheet in Smartsheet"
                        >
                          {p.name}
                          <ExternalLink size={12} strokeWidth={2.4} />
                        </a>
                      ) : (
                        <span className="project-name">{p.name}</span>
                      )}
                      {!p.error && section.key !== 'scheduled' && (
                        <span className="project-pct mono">{p.percentComplete}%</span>
                      )}
                      {!p.error && section.key === 'scheduled' && p.startsFrom && (
                        <span className="project-starts mono">Starts {formatStartsFrom(p.startsFrom)}</span>
                      )}
                    </div>

                    {p.error ? (
                      <div className="project-error">
                        <AlertTriangle size={13} strokeWidth={2.2} />
                        Couldn't load this sheet — {p.error}
                      </div>
                    ) : (
                      <>
                        {section.key !== 'scheduled' && (
                          <div className="project-bar-track">
                            <div className="project-bar-fill" style={{ width: `${p.percentComplete}%` }} />
                          </div>
                        )}
                        <div className="project-counts">
                          {section.key !== 'completed' && (
                            <span className="count-item active">
                              <span className="swatch" />
                              {p.active} active {p.active === 1 ? 'property' : 'properties'}
                            </span>
                          )}
                          <span className="count-item done">
                            <span className="swatch" />
                            {p.done} completed {p.done === 1 ? 'property' : 'properties'}
                          </span>
                          <span className="project-total mono">{p.total} total</span>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
