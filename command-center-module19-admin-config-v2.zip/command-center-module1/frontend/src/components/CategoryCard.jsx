import { useMemo } from 'react';
import SignalBar from './SignalBar';
import { effectiveOverdue } from '../utils/sla';
import { useOverdueOverrides } from '../context/OverdueContext';

export default function CategoryCard({ categoryKey, bucket, isOpen, onSelect }) {
  const { reviewedIds } = useOverdueOverrides();
  const { label, description, counts } = bucket;
  const active = counts.active || 0;
  const pending = counts.pending_client || 0;
  const done = counts.done || 0;
  const total = active + pending + done + (counts.unknown || 0);
  const isQuiet = total > 0 && active === 0;

  const overdue = useMemo(
    () => bucket.cases.filter((c) => effectiveOverdue(c, reviewedIds)).length,
    [bucket.cases, reviewedIds]
  );

  return (
    <button
      type="button"
      className={`category-card${isOpen ? ' is-open' : ''}${isQuiet ? ' is-quiet' : ''}${
        overdue > 0 ? ' has-overdue' : ''
      }`}
      onClick={() => onSelect(categoryKey)}
      aria-pressed={isOpen}
    >
      <SignalBar active={active} total={total} hasOverdue={overdue > 0} />
      <div className="category-body">
        <span className="category-total mono">{total}</span>
        <div className="category-head">
          <span className="category-label">{label}</span>
          <span className="category-desc">{description}</span>
        </div>
        <div className="category-counts">
          <span className="count-item active">
            <span className="swatch" />
            {active}
          </span>
          <span className="count-item pending" title="Case Responded">
            <span className="swatch" />
            {pending}
          </span>
          <span className="count-item done">
            <span className="swatch" />
            {done}
          </span>
          {overdue > 0 && (
            <span className="count-item overdue">
              <span className="swatch" />
              {overdue} overdue
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
