import { useEffect, useState } from 'react';
import { fetchHiltonRolloutSchedule, fetchHiltonRebuildSchedule, fetchHiltonProjectSchedule } from '../api/client';
import { toISODate } from '../utils/week';

/**
 * Pulls today's activity across whatever's live — right now just Hilton's
 * wave rollout + rebuild schedule + project-tracker schedule, but shaped so
 * adding another client here later is a one-line addition, not a redesign.
 */
export function useTodayActivity() {
  const [waves, setWaves] = useState([]);
  const [rebuilds, setRebuilds] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const today = toISODate(new Date());

    (async () => {
      try {
        const [rollout, rebuild, projectSchedule] = await Promise.all([
          fetchHiltonRolloutSchedule(today, today),
          fetchHiltonRebuildSchedule(),
          fetchHiltonProjectSchedule(today, today),
        ]);
        if (cancelled) return;
        setWaves((rollout.cells || []).filter((c) => c.date === today).map((c) => ({ ...c, client: 'Hilton' })));
        setRebuilds(
          (rebuild.items || []).filter((i) => i.scheduledDate === today).map((i) => ({ ...i, client: 'Hilton' }))
        );
        setProjects(
          (projectSchedule.cells || []).filter((c) => c.date === today).map((c) => ({ ...c, client: 'Hilton' }))
        );
        setError(null);
      } catch (err) {
        if (!cancelled) setError(err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  return { waves, rebuilds, projects, loading, error };
}
