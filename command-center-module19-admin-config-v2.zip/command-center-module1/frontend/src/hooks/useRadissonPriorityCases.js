import { useEffect, useRef, useState, useCallback } from 'react';
import { fetchRadissonPriorityCases } from '../api/client';

const POLL_MS = 30_000;

export function useRadissonPriorityCases() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef(null);

  const load = useCallback(async ({ silent } = {}) => {
    if (!silent) setLoading(true);
    try {
      const result = await fetchRadissonPriorityCases();
      setData(result);
      setError(null);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    timerRef.current = setInterval(() => load({ silent: true }), POLL_MS);
    return () => clearInterval(timerRef.current);
  }, [load]);

  const refresh = useCallback(() => load({ silent: true }), [load]);

  return { data, error, loading, refresh };
}
