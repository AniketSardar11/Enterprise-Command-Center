import { useCallback, useEffect, useMemo, useState } from 'react';
import { fetchHiltonRolloutSchedule, fetchHiltonRebuildSchedule, fetchHiltonProjectSchedule } from '../api/client';
import { getMonday, addDays, toISODate } from '../utils/week';

// Pad the raw-item request window beyond just the visible week so quick
// prev/next clicks don't need a refetch — cells (the actual calendar payload)
// always come back computed from the full sheet regardless of this window.
const PAD_DAYS = 21;

export function useWeekCalendar(initialDate = new Date()) {
  const [weekStart, setWeekStart] = useState(() => getMonday(initialDate));
  const [rollout, setRollout] = useState(null);
  const [rebuild, setRebuild] = useState(null);
  const [projectSchedule, setProjectSchedule] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async (monday) => {
    setLoading(true);
    try {
      const from = toISODate(addDays(monday, -PAD_DAYS));
      const to = toISODate(addDays(monday, 4 + PAD_DAYS));
      const [rolloutRes, rebuildRes, projectScheduleRes] = await Promise.all([
        fetchHiltonRolloutSchedule(from, to),
        fetchHiltonRebuildSchedule(),
        fetchHiltonProjectSchedule(from, to),
      ]);
      setRollout(rolloutRes);
      setRebuild(rebuildRes);
      setProjectSchedule(projectScheduleRes);
      setError(null);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(weekStart);
  }, [weekStart, load]);

  const goToToday = useCallback(() => setWeekStart(getMonday(new Date())), []);
  const goPrevWeek = useCallback(() => setWeekStart((w) => addDays(w, -7)), []);
  const goNextWeek = useCallback(() => setWeekStart((w) => addDays(w, 7)), []);

  // Cells + rebuild items scoped to just the 5 visible weekdays.
  const weekDates = useMemo(() => [0, 1, 2, 3, 4].map((n) => toISODate(addDays(weekStart, n))), [weekStart]);

  const cellsByDate = useMemo(() => {
    const map = new Map(weekDates.map((d) => [d, []]));
    (rollout?.cells || []).forEach((cell) => {
      if (map.has(cell.date)) map.get(cell.date).push(cell);
    });
    return map;
  }, [rollout, weekDates]);

  const rebuildByDate = useMemo(() => {
    const map = new Map(weekDates.map((d) => [d, []]));
    (rebuild?.items || []).forEach((item) => {
      if (item.scheduledDate && map.has(item.scheduledDate)) {
        map.get(item.scheduledDate).push(item);
      }
    });
    return map;
  }, [rebuild, weekDates]);

  // Same aggregated-cell shape as cellsByDate (rollout waves) — one cell per
  // (date, project) with a not-yet-done property count, so the Projects
  // calendar row renders the same way the Wave row does.
  const projectCellsByDate = useMemo(() => {
    const map = new Map(weekDates.map((d) => [d, []]));
    (projectSchedule?.cells || []).forEach((cell) => {
      if (map.has(cell.date)) map.get(cell.date).push(cell);
    });
    return map;
  }, [projectSchedule, weekDates]);

  const unscheduledRebuildCount = rebuild?.items?.filter((i) => !i.scheduledDate).length || 0;

  return {
    weekStart,
    weekDates,
    cellsByDate,
    rebuildByDate,
    projectCellsByDate,
    unscheduledRebuildCount,
    loading,
    error,
    goToToday,
    goPrevWeek,
    goNextWeek,
    refresh: () => load(weekStart),
  };
}
