import { useEffect, useRef, useState, useCallback } from 'react';
import { fetchHiltonCases } from '../api/client';

const POLL_MS = 30_000;

/**
 * Polls the Hilton cases endpoint and exposes the latest snapshot,
 * a loading/error state, and how long ago the data was fetched
 * (for the live-status indicator in the masthead).
 */
export function useHiltonCases() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastFetchedAt, setLastFetchedAt] = useState(null);
  const timerRef = useRef(null);

  const load = useCallback(async ({ silent } = {}) => {
    if (!silent) setLoading(true);
    try {
      const result = await fetchHiltonCases();
      setData(result);
      setError(null);
      setLastFetchedAt(Date.now());
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    timerRef.current = setInterval(() => load({ silent: true }), POLL_MS);
    return () => clearInterval(timerRef.current);
  }, [load]);

  const refresh = useCallback(() => load({ silent: true }), [load]);

  return { data, error, loading, lastFetchedAt, refresh };
}
