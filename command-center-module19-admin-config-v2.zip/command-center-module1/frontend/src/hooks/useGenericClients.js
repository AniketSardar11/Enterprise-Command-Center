import { useEffect, useRef, useState, useCallback } from 'react';
import { fetchGenericClientCases, fetchGenericClientProjects } from '../api/client';

const POLL_MS = 30_000;

/**
 * Hilton and Radisson each get their own hook (useHiltonCases,
 * useRadissonCases) because they have dedicated backend services. Every
 * other client that's marked `live: true` in data/clients.js but doesn't
 * have one of those goes through here instead — one hook, keyed by
 * clientKey, so a new client going live is a data/clients.js edit (flip
 * `live: true`) plus admin-form entries, not new hook/wiring code.
 *
 * @param {string[]} clientKeys - stable-ish array of client keys to poll (e.g. ['hyatt'])
 * @returns {{ [clientKey]: { data, projectsData, error, loading, lastFetchedAt, refresh } }}
 */
export function useGenericClients(clientKeys) {
  const [state, setState] = useState({});
  const timerRef = useRef(null);
  const keysSignature = clientKeys.join(',');

  const load = useCallback(
    async ({ silent } = {}) => {
      const keys = keysSignature ? keysSignature.split(',') : [];
      if (keys.length === 0) return;

      if (!silent) {
        setState((prev) => {
          const next = { ...prev };
          keys.forEach((key) => {
            next[key] = { ...(next[key] || {}), loading: true };
          });
          return next;
        });
      }

      await Promise.all(
        keys.map(async (key) => {
          try {
            const [data, projectsData] = await Promise.all([
              fetchGenericClientCases(key),
              fetchGenericClientProjects(key).catch(() => null), // projects are optional — don't fail the whole client on a projects error
            ]);
            setState((prev) => ({
              ...prev,
              [key]: { data, projectsData, error: null, loading: false, lastFetchedAt: Date.now() },
            }));
          } catch (error) {
            setState((prev) => ({
              ...prev,
              [key]: { ...(prev[key] || {}), error, loading: false },
            }));
          }
        })
      );
    },
    [keysSignature]
  );

  useEffect(() => {
    if (!keysSignature) return undefined;
    load();
    timerRef.current = setInterval(() => load({ silent: true }), POLL_MS);
    return () => clearInterval(timerRef.current);
  }, [keysSignature, load]);

  const refresh = useCallback(() => load({ silent: true }), [load]);

  return { byClient: state, refresh };
}
