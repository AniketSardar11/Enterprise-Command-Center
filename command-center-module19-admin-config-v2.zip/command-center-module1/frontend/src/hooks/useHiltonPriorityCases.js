import { useEffect, useRef, useState, useCallback } from 'react';
import { fetchHiltonPriorityCases } from '../api/client';

const POLL_MS = 30_000;

/**
 * Polls the T-priority cases endpoint. Same shape as useHiltonCases so the
 * two data sources can sit side by side in the UI without special-casing.
 */
export function useHiltonPriorityCases() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastFetchedAt, setLastFetchedAt] = useState(null);
  const timerRef = useRef(null);

  const load = useCallback(async ({ silent } = {}) => {
    if (!silent) setLoading(true);
    try {
      const result = await fetchHiltonPriorityCases();
      setData(result);
      setError(null);
      setLastFetchedAt(Date.now());
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    timerRef.current = setInterval(() => load({ silent: true }), POLL_MS);
    return () => clearInterval(timerRef.current);
  }, [load]);

  const refresh = useCallback(() => load({ silent: true }), [load]);

  return { data, error, loading, lastFetchedAt, refresh };
}
