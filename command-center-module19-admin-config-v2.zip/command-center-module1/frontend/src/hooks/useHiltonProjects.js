import { useEffect, useRef, useState, useCallback } from 'react';
import { fetchHiltonProjects } from '../api/client';

const POLL_MS = 60_000; // projects change slowly — poll less aggressively than case data

export function useHiltonProjects() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const timerRef = useRef(null);

  const load = useCallback(async ({ silent } = {}) => {
    if (!silent) setLoading(true);
    try {
      const result = await fetchHiltonProjects();
      setData(result);
      setError(null);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    timerRef.current = setInterval(() => load({ silent: true }), POLL_MS);
    return () => clearInterval(timerRef.current);
  }, [load]);

  const refresh = useCallback(() => load({ silent: true }), [load]);

  return { data, error, loading, refresh };
}
