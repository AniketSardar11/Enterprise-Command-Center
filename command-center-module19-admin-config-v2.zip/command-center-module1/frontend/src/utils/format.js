export const STATUS_META = {
  overdue: { label: 'Overdue', order: -1 },
  active: { label: 'Active', order: 0 },
  pending_client: { label: 'Case Responded', order: 1 },
  done: { label: 'Done', order: 2 },
  unknown: { label: 'Unknown', order: 3 },
};

export function relativeTime(iso) {
  if (!iso) return '—';
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return '—';
  const diffMs = Date.now() - then;
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 5) return 'just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 30) return `${diffDay}d ago`;
  const diffMonth = Math.floor(diffDay / 30);
  return `${diffMonth}mo ago`;
}

export function secondsAgoLabel(timestampMs) {
  if (!timestampMs) return null;
  const sec = Math.floor((Date.now() - timestampMs) / 1000);
  if (sec < 3) return 'live';
  if (sec < 60) return `synced ${sec}s ago`;
  const min = Math.floor(sec / 60);
  return `synced ${min}m ago`;
}
