const DAY_MS = 86400000;

export function toISODate(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/** Monday of the week containing `date` (local time, not UTC-shifted). */
export function getMonday(date) {
  const d = new Date(date);
  const day = d.getDay(); // 0 = Sunday, 1 = Monday, ...
  const diff = day === 0 ? -6 : 1 - day; // shift Sunday back to the *previous* Monday
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

export function addDays(date, n) {
  return new Date(date.getTime() + n * DAY_MS);
}

/** Mon–Fri (5 workdays) starting from a given Monday. */
export function getWorkweek(monday) {
  return [0, 1, 2, 3, 4].map((n) => addDays(monday, n));
}

export function formatWeekRange(monday) {
  const friday = addDays(monday, 4);
  const sameMonth = monday.getMonth() === friday.getMonth();
  const startFmt = monday.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const endFmt = friday.toLocaleDateString('en-US', {
    month: sameMonth ? undefined : 'short',
    day: 'numeric',
    year: 'numeric',
  });
  return `${startFmt} – ${endFmt}`;
}

export function formatDayHeader(date) {
  return {
    weekday: date.toLocaleDateString('en-US', { weekday: 'short' }),
    dayNum: date.getDate(),
  };
}

export function isSameDate(a, b) {
  return toISODate(a) === toISODate(b);
}
