// Every case reason gets one week to move before it's flagged overdue.
// This is a simple, uniform SLA for now — per-category SLAs (e.g. a faster
// clock for De-Install vs. a slower one for Demand360) can replace the
// constant below once the business rules are confirmed.
export const DEFAULT_SLA_DAYS = 7;

/** True if an open case has sat active past its SLA window, ignoring manual review overrides. */
export function isOverdue(c, slaDays = DEFAULT_SLA_DAYS) {
  if (!c || c.operationalStatus !== 'active') return false;
  const ref = c.lastModifiedDate || c.createdDate;
  if (!ref) return false;
  const ageMs = Date.now() - new Date(ref).getTime();
  return ageMs > slaDays * 86400000;
}

/**
 * The overdue state actually shown in the UI: date-based overdue, unless
 * someone has marked this specific case reviewed (see OverdueContext).
 */
export function effectiveOverdue(c, reviewedIds) {
  if (!isOverdue(c)) return false;
  return !reviewedIds || !reviewedIds.has(c.id);
}

/** Whole days since a case's reference date (last touched, or created). */
export function daysOpen(c) {
  const ref = c.lastModifiedDate || c.createdDate;
  if (!ref) return null;
  const ageMs = Date.now() - new Date(ref).getTime();
  return Math.floor(ageMs / 86400000);
}

/** Tally active/pending/done/overdue across a list of cases. Pass reviewedIds to respect overrides. */
export function tally(cases, reviewedIds) {
  const t = { active: 0, pending_client: 0, done: 0, unknown: 0, overdue: 0 };
  cases.forEach((c) => {
    t[c.operationalStatus] = (t[c.operationalStatus] || 0) + 1;
    if (effectiveOverdue(c, reviewedIds)) t.overdue += 1;
  });
  return t;
}
