// Registry of client boards shown as tiles on the Enterprise home screen.
// Only "live" clients have a backend endpoint wired up; others render as
// disabled "not connected yet" tiles until their integration ships.
// `code` is the internal client/account code (e.g. G3_Client_Code__c in SFDC)
// used once each client's backend integration is wired up.
//
// `capabilities` tells the board which tabs/data sources actually exist for
// this client, so ClientBoard can hide what isn't ready yet instead of
// showing a broken or empty tab. Every live client has `im` (installs/
// SFDC cases) at minimum; `t` (priority cases), `calendar`, and `projects`
// come online as each client's Smartsheet/T-case integration is confirmed.
export const CLIENTS = [
  {
    key: 'hilton',
    name: 'Hilton',
    initials: 'HL',
    code: 'HILTON',
    live: true,
    capabilities: { im: true, t: true, calendar: true, projects: true },
  },
  {
    key: 'radisson',
    name: 'Radisson',
    initials: 'RD',
    code: 'RHAB',
    live: true,
    // No Smartsheet projects/calendar exist yet for Radisson — ready to flip
    // on the moment either shows up, same pattern as Hilton.
    capabilities: { im: true, t: true, calendar: false, projects: false },
  },
  {
    key: 'accor',
    name: 'Accor',
    initials: 'AC',
    code: 'ACCOR',
    live: false,
  },
  {
    key: 'atlantis',
    name: 'Atlantis',
    initials: 'AT',
    code: 'APIB',
    live: false,
  },
  {
    key: 'choice',
    name: 'Choice (G3 & Elevate)',
    initials: 'CH',
    code: 'CHOI',
    live: false,
  },
  {
    key: 'hyatt',
    name: 'Hyatt',
    initials: 'HY',
    code: 'HYI',
    live: true,
    // SFDC identifiers confirmed (chainCode 'HYI' in clientIdentifiers.js)
    // but no hand-written taxonomy yet — categories come entirely from the
    // admin form (Admin -> Board Config) until enough are added to warrant
    // a dedicated service like Hilton/Radisson have. `t` and `calendar`
    // stay off until those are confirmed too.
    capabilities: { im: true, t: false, calendar: false, projects: true },
  },
  {
    key: 'marriott',
    name: 'Marriott / Elegant Hotels',
    initials: 'MR',
    code: 'MARR',
    live: false,
  },
  {
    key: 'mvw',
    name: 'MVW',
    initials: 'MV',
    code: 'MVW',
    live: false,
  },
  {
    key: 'mgm',
    name: 'MGM',
    initials: 'MG',
    code: 'MGM',
    live: false,
  },
  {
    key: 'universal',
    name: 'Universal / UCF Hotel Venture',
    initials: 'UN',
    code: 'UNIV',
    live: false,
  },
  {
    key: 'venetian',
    name: 'Venetian',
    initials: 'VN',
    code: 'VLVG / LVS',
    live: false,
  },
  {
    key: 'wyndham',
    name: 'Wyndham (Elevate)',
    initials: 'WY',
    code: 'WYND',
    live: false,
  },
];

export function getClient(key) {
  return CLIENTS.find((c) => c.key === key) || null;
}
