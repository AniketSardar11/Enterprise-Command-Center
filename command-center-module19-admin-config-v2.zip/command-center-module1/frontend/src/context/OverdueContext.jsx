import { createContext, useContext, useCallback, useMemo, useState, useEffect } from 'react';

const STORAGE_KEY = 'cc_overdue_reviewed_v1';
const OverdueContext = createContext(null);

function loadStored() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return new Set();
    return new Set(JSON.parse(raw));
  } catch {
    return new Set();
  }
}

function persist(set) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify([...set]));
  } catch {
    // storage unavailable (private browsing, etc.) — override still works for this session
  }
}

/**
 * Some cases sit "Active" past the 7-day SLA for reasons that aren't really
 * neglect (client-side delay outside SFDC, a known blocker, etc). This lets
 * someone mark those reviewed so the board stops flagging them red — without
 * needing to touch the underlying SFDC status. Marking is per-browser, not
 * per-case-forever: if the case gets touched again in SFDC and goes overdue
 * again later, it's still tracked the same way (the override just silences
 * the CURRENT overdue window).
 */
export function OverdueProvider({ children }) {
  const [reviewedIds, setReviewedIds] = useState(loadStored);

  useEffect(() => {
    persist(reviewedIds);
  }, [reviewedIds]);

  const markReviewed = useCallback((id) => {
    setReviewedIds((prev) => new Set(prev).add(id));
  }, []);

  const unmarkReviewed = useCallback((id) => {
    setReviewedIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  }, []);

  const toggleReviewed = useCallback((id) => {
    setReviewedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const value = useMemo(
    () => ({ reviewedIds, markReviewed, unmarkReviewed, toggleReviewed }),
    [reviewedIds, markReviewed, unmarkReviewed, toggleReviewed]
  );

  return <OverdueContext.Provider value={value}>{children}</OverdueContext.Provider>;
}

export function useOverdueOverrides() {
  const ctx = useContext(OverdueContext);
  if (!ctx) throw new Error('useOverdueOverrides must be used within OverdueProvider');
  return ctx;
}
